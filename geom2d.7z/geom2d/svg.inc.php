<?php
/*PhpDoc:
name:  svg.inc.php
title: svg.inc.php - génération d'ordres SVG
includes: [ 'geom2d.inc.php' ]
classes:
doc: |
  Simplification de la réalisation de dessins SVG
journal: |
  13/6/2016
    possibilité de désactiver la bufferisation active par défaut
  12/6/2016
    améliorations
  11/6/2016
    première version
*/
require_once 'geom2d.inc.php';

/*PhpDoc: classes
name:  Svg
title: class Svg - Dessin SVG
methods:
doc: |
  Les méthodes de cette classe correspondent aux primitives SVG.
  Les ordres sont stockés dans l'objet et affichés sur l'ordre close()
*/
class Svg {
  private $store = 1;
  private $orders=[]; // Liste des ordres SVG
  
/*PhpDoc: methods
name:  __construct
title: function __construct($width, $height, $viewbox=null)
doc: |
  Définition de la taille de l'image et du viewbox sous la forme ['xmin'=>xmin, 'ymin'=>ymin, 'width'=>width, 'height'=>height]
*/
  function __construct($width, $height, $viewbox=null) {
    if ($viewbox)
      $this->orders[] =
        sprintf("<svg xmlns='http://www.w3.org/2000/svg' version='1.1' baseProfile='full' "
               ."width='%d' height='%d' viewBox='%d %d %d %d'>",
                $width, $height, $viewbox['xmin'], $viewbox['ymin'], $viewbox['width'], $viewbox['height']);
    else
      $this->orders[] =
        sprintf("<svg xmlns='http://www.w3.org/2000/svg' version='1.1' baseProfile='full' width='%d' height='%d'>",
                $width, $height);
  }
  
/*PhpDoc: methods
name:  close
title: function close($href=null) - génère les ordres SVG stockés, si href<>null alors ajout d'un <a href></a>
*/
  function close($href=null) {
    if ($href)
      echo "<a href='$href'>\n";
    foreach ($this->orders as $order)
      echo "$order\n";
    echo "</svg>\n";
    if ($href)
      echo "</a>\n";
    $this->orders = [];
  }
    
/*PhpDoc: methods
name:  nobuffer
title: function nobuffer() - désactive la mise en buffer
*/
  function nobuffer() {
    foreach ($this->orders as $order)
      echo "$order\n";
    $this->orders = [];
  }
    
/*PhpDoc: methods
name:  exec
title: private function exec($order) - exécute un ordre
*/
  private function exec($order) {
    if ($this->orders)
      $this->orders[] = $order;
    else
      echo "$order\n";
  }
    
/*PhpDoc: methods
name:  image
title: function image($url, $x, $y, $width, $height, $stroke='black', $fill='transparent', $stroke_width=2)
*/
  function image($url, $x, $y, $width, $height, $stroke='black', $fill='transparent', $stroke_width=2) {
    $this->exec(
      sprintf("<image xlink:href='%s' x='%d' y='%d' width='%d' height='%d'/>", $url, $x, $y, $width, $height));
  }
  
/*PhpDoc: methods
name:  rect
title: function rect($x, $y, $width, $height, $url=null, $stroke='black', $fill='transparent', $stroke_width=2)
*/
  function rect($x, $y, $width, $height, $url=null, $stroke='black', $fill='transparent', $stroke_width=2) {
    $this->exec(
      ($url ?
        sprintf("<a xlink:href='%s'><rect x='%d' y='%d' width='%d' height='%d' stroke='%s' fill='%s' stroke-width='%d'/></a>",
                                $url,        $x,    $y,    $width,    $height,    $stroke,    $fill,    $stroke_width) :
        sprintf("<rect x='%d' y='%d' width='%d' height='%d' stroke='%s' fill='%s' stroke-width='%d'/>",
                        $x,    $y,    $width,    $height,    $stroke,    $fill,    $stroke_width)));
  }
  
/*PhpDoc: methods
name:  line
title: function line($pt1, $pt2, $stroke='black', $fill='transparent', $stroke_width=1)
*/
  function line($pt1, $pt2, $stroke='black', $fill='transparent', $stroke_width=1) {
//    echo "Svg::line(pt1=$pt1, pt2=$pt2)<br>\n";
    $this->exec(
      sprintf("<line x1='%d' y1='%d' x2='%d' y2='%d' stroke='%s' fill='%s' stroke-width='%d'/>",
                  $pt1->x(), $pt1->y(), $pt2->x(), $pt2->y(), $stroke, $fill, $stroke_width));
  }
  
/*PhpDoc: methods
name:  polygon
title: function polygon($pts, $stroke='black', $fill='transparent', $stroke_width=1)
*/
  function polygon($pts, $stroke='black', $fill='transparent', $stroke_width=1) {
    $ptstrings = [];
    foreach ($pts as $pt)
      $ptstrings[] = sprintf("%d,%d",$pt->x(), $pt->y());
    $this->exec(
      sprintf("<polygon points='%s' stroke='%s' fill='%s' stroke-width='%d'/>",
                  implode(' ',$ptstrings), $stroke, $fill, $stroke_width));
  }
};

if (basename(__FILE__)<>basename($_SERVER['PHP_SELF'])) return;

$svg = new Svg(500, 300);
$svg->rect(10, 10, 100, 70, 'http://gnym.migcat.fr/');
$svg->close();
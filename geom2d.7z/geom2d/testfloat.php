<?php
// testfloat
$val = 200.0;
$epsilon = 1e-13*$val;

echo "val+epsilon=",$val+$epsilon,"<br>\n";
<?php
/*PhpDoc:
name:  drawing.inc.php
title: drawing.inc.php - Dessin en coordonnées terrain, dans un premier temps en Lambert93
includes: [ 'svg.inc.php' ]
classes:
doc: |
  L'objectif est de dessiner de manière simple des objets geom2d définis en Lambert 93
journal: |
  11/6/2016
    première version
*/
require_once 'svg.inc.php';

/*PhpDoc: classes
name:  Drawing
title: class Drawing - Sur-couche de Svg pour dessiner des objets geom2d en Lambert 93
methods:
doc: |
  La transformation est définie par un bbox en coord terrain et 2 points en coord SVG
  Drawing est une sous-classe de Svg qui rajoute les méthodes de dessin en coordonnées terrain
*/
class Drawing extends Svg {
  private $tBbox; // boite en coordonnées terrain
  private $svgBottomLeftPoint; // Point en bas à gauche en coord SVG
  private $svgTopRightPoint; // Point en bas à gauche en coord SVG
  
/*PhpDoc: methods
name:  __construct
title: function __construct(BBox $tBbox, Point $svgBottomLeftPoint, Point $svgTopRightPoint)
doc: |
  La transformation est définie par un bbox en coord terrain et 2 points en coord SVG
  Drawing est une sous-classe de Svg qui rajoute les méthodes de dessin en coordonnées terrain
*/
  function __construct(BBox $tBbox, Point $svgBottomLeftPoint, Point $svgTopRightPoint) {
//    echo "Drawing::__construct(tBbox=$tBbox, svgBottomLeftPoint=$svgBottomLeftPoint, svgTopRightPoint=$svgTopRightPoint<br>\n";
    $this->tBbox = $tBbox;
    $this->svgBottomLeftPoint = $svgBottomLeftPoint;
    $this->svgTopRightPoint = $svgTopRightPoint;
    parent::__construct($svgTopRightPoint->x()-$svgBottomLeftPoint->x(), $svgBottomLeftPoint->y()-$svgTopRightPoint->y(),
                        ['xmin'=>$svgBottomLeftPoint->x(), 'ymin'=>$svgTopRightPoint->y(),
                         'width'=>$svgTopRightPoint->x()-$svgBottomLeftPoint->x(), 'height'=>$svgBottomLeftPoint->y()-$svgTopRightPoint->y()]);
  }
  
/*PhpDoc: methods
name:  proj
title: function proj(Point $tPt) - transformation Terrain -> SVG
*/
  function proj(Point $tPt) {
    $x = $this->svgBottomLeftPoint->x() + ($tPt->x() - $this->tBbox->min()->x()) * ($this->svgTopRightPoint->x() - $this->svgBottomLeftPoint->x()) / ($this->tBbox->max()->x() - $this->tBbox->min()->x());
    $y = $this->svgBottomLeftPoint->y() + ($tPt->y() - $this->tBbox->min()->y()) * ($this->svgTopRightPoint->y() - $this->svgBottomLeftPoint->y()) / ($this->tBbox->max()->y() - $this->tBbox->min()->y());
    return new Point(['x'=>round($x), 'y'=>round($y)]);
  }
  
/*PhpDoc: methods
name:  drawBBox
title: function drawBBox(BBox $tBb, $url=null, $stroke='black', $fill='transparent', $stroke_with=2)
*/
  function drawBBox(BBox $tBb, $url=null, $stroke='black', $fill='transparent', $stroke_with=2) {
    $svgTopLeft  = $this->proj(new Point(['x'=>$tBb->min()->x(), 'y'=>$tBb->max()->y()]));
    $svgBotRight = $this->proj(new Point(['x'=>$tBb->max()->x(), 'y'=>$tBb->min()->y()]));
    $this->rect(
      round($svgTopLeft->x()), // x
      round($svgTopLeft->y()), // y
      round($svgBotRight->x() - $svgTopLeft->x()), // width
      round($svgBotRight->y() - $svgTopLeft->y()), // height
      $url, $stroke, $fill, $stroke_with);              
  }
  
/*PhpDoc: methods
name:  drawGeomCollection
title: function drawGeomCollection($geom, $stroke='black', $fill='transparent', $stroke_with=2)
*/
  function drawGeomCollection($geom, $stroke='black', $fill='transparent', $stroke_with=2) {
//    echo "Drawing::drawGeomCollection(geom=$geom)<br>\n";
    $geom->draw($this, $stroke, $fill, $stroke_with);
  }
  
/*PhpDoc: methods
name:  drawLineString
title: function drawLineString($pointlist, $stroke='black', $fill='transparent', $stroke_width=2)
*/
  function drawLineString($pointlist, $stroke='black', $fill='transparent', $stroke_width=2) {
//    echo "Drawing::drawLineString(pointlist=(",implode(',',$pointlist),")<br>\n";
    $pt0 = null;
    foreach ($pointlist as $pt) {
      $pt = $this->proj($pt);
      if ($pt0 and ($pt<>$pt0))
        $this->line($pt0, $pt, $stroke, $fill, $stroke_width);
      $pt0 = $pt;
    }
  }
  
/*PhpDoc: methods
name:  drawPolygon
title: function drawPolygon($linestrings, $stroke='black', $fill='transparent', $stroke_width=2)
*/
  function drawPolygon($linestrings, $stroke='black', $fill='transparent', $stroke_width=2) {
//    echo "Drawing::drawPolygon(linestrings=(",implode(',',$linestrings),")<br>\n";
// Remplissage de l'intérieur
    if ($fill<>'transparent') {
      if (!isset($linestrings[0]->points()[0])) {
        echo "<pre>";
        throw new Exception("Point non défini dans ".__FILE__.", ligne ".__LINE__);
      }
      $pt0 = $linestrings[0]->points()[0]; // le premier point du contour extérieur
      $pts = [];
      foreach($linestrings as $no => $linestring) {
        foreach ($linestring->points() as $pt)
          $pts[] = $this->proj($pt);
        if ($no > 0)
          $pts[] = $this->proj($pt0);
      }
      $this->polygon($pts, 'transparent', $fill, 0);
    }
// puis dessin du contour
    if ($stroke<>'transparent')
      foreach ($linestrings as $no => $linestring) {
        $ptPrec = null;
        foreach ($linestring->points() as $pt) {
          $pt = $this->proj($pt);
          if ($ptPrec and ($pt<>$ptPrec))
            $this->line($ptPrec, $pt, $stroke, 'transparent', $stroke_width);
          $ptPrec = $pt;
        }
      }
  }
};


if (basename(__FILE__)<>basename($_SERVER['PHP_SELF'])) return;
echo "<html><head><meta charset='UTF-8'><title>drawing</title></head><body><pre>";

function rectangle($x, $y, $dx, $dy) {
  return new LineString(sprintf('LINESTRING(%d %d,%d %d,%d %d,%d %d,%d %d)',$x,$y,$x+$dx,$y,$x+$dx,$y+$dy,$x,$y+$dy,$x,$y));
}

if (1) {
// Test du dessin d'un polygone avec trous
  $drawing = new Drawing(new BBox(0, 0, 1000, 700), new Point(['x'=>0, 'y'=>700]), new Point(['x'=>1000, 'y'=>0]));
//  $drawing->rect(10, 10, 990, 690);
  $ext = new LineString('LINESTRING(100 100,900 100,900 600,100 600,100 100)');
//  $ext->draw($drawing, 'grey', 'transparent', 2);
  $hole1 = new LineString(array_reverse(rectangle(200, 200, 100, 100)->points()));
//  $hole1->draw($drawing, 'red', 'transparent', 2);
  $hole2 = new LineString(array_reverse(rectangle(500, 400, 100, 100)->points()));
//  $hole2->draw($drawing, 'orange', 'transparent', 2);
  $hole3 = new LineString(array_reverse(rectangle(700, 300, 100, 100)->points()));
  $pol = new Polygon([$ext, $hole1, $hole2, $hole3]);
  $pol->draw($drawing, 'blue', 'lightBlue', 2);
  $drawing->close();
}

if (0) {
  $drawing = new Drawing(new BBox(1000, 5000, 1300, 5200), new Point(['x'=>10, 'y'=>800]), new Point(['x'=>990, 'y'=>10]));
  $drawing->rect(10, 10, 100, 70);
  $drawing->drawBBox(new BBox(1050, 5010, 1250, 5190));
  $drawing->close();

  foreach ([
      new Point(['x'=>1000, 'y'=>5000]),
      new Point(['x'=>1001, 'y'=>5001]),
      new Point(['x'=>1150, 'y'=>5100]),
      new Point(['x'=>1300, 'y'=>5200]),
    ] as $pt)
      echo "<p>Point $pt -> ",$drawing->proj($pt),"</p>\n";
}

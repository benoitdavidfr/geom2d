#!/usr/bin/perl
#
use strict;
my $ident = "genmifmid - Benoit DAVID - 17/1/05 8:00";
# Generation de fichiers MIF/MID a partir d'une requete MySQL 4.1 
#
# 17/1/05
# -------
# - Traitement d'une requete SQL complete
#
# 14/1/05
# -------
# - Affichage de la liste des parametres definis lorsqu'aucun n'est passe
# - Chgt des parametres de couleur des tables autoroutier, principal, regional et local
#
# 10/1/05
# -------
# - Chgt du nom de dechargemifmid a genmifmid
#
# 3/1/05
# -------
# - Parametrage du dechargement
#
# 10/12/04
# -------
# - 1ere version
#
use Geom;
# my $param = 'principal';
# my $param = 'regional';
# my $param = 'local';
# my $param = 'comroute';

# Description des parametres
#  fichiers : chemin des fichiers MIF/MID a ecrire
#  table    : nom de la table a interroger
#  colonnes : liste des colonnes avec pour chaque:
#    0 -> nom MapInfo et MySQL
#    1 -> type MapInfo
#    2 et 3 -> parametres du type ou ''
#  critere  : eventuellement clause WHERE
#  select   : requete SQL complete eventuellement a la place de table et critere
#  repgraf  : eventuellement fonction de representation graphique
#             prenant le n-uplet en parametre sous la forme d'un hachage
#             et rendant un texte a inserer dans le fichier MIF
my %parametres = (
  autoroutier =>
   { fichiers => 'autoroutier',
     table    => 'comroute',
     colonnes => [['comroute','char',16,''],
                  ['insee','char',5,''],
                  ['route','char',10,''],
                  ['agg45','char',16,''],
                  ['vocation','char',20,''],
                  ['longueur','float','',''],
                  ['nbacc','integer','',''],
                  ['nbacg','integer','',''],
                  ['nbacm','integer','',''],
                  ['nbbl','integer','',''],
                  ['nbbg','integer','',''],
                  ['nbtue','integer','',''],
                  ['dacg','float','',''],
                  ['dacg45','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
     critere  => "vocation='Type autoroutier'",
     repgraf  => sub {
                  my %pf = @_;
                  my $width=2;
                  my $color=0;
                  if ($pf{dacg45}<0.8) { $color=16711680; }
                  if ($pf{dacg45}<0.6) { $color=16740416; }
                  if ($pf{dacg45}<0.4) { $color=255; }
                  if ($pf{dacg45}<0.2) { $color=65280; }
                  return "Pen ($width,2,$color)";
                 },
   },
  principal =>
   { fichiers => 'principal',
     table    => 'comroute',
     colonnes => [['comroute','char',16,''],
                  ['insee','char',5,''],
                  ['route','char',10,''],
                  ['agg45','char',16,''],
                  ['vocation','char',20,''],
                  ['longueur','float','',''],
                  ['nbacc','integer','',''],
                  ['nbacg','integer','',''],
                  ['nbacm','integer','',''],
                  ['nbbl','integer','',''],
                  ['nbbg','integer','',''],
                  ['nbtue','integer','',''],
                  ['dacg','float','',''],
                  ['dacg45','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
     critere  => "vocation='Type autoroutier' or vocation='Liaison principale'",
     repgraf  => sub {
                  my %pf = @_;
                  my $width=3;
                  if ($pf{vocation} eq 'Liaison principale') { $width=2; }
                  my $color=0;
                  if ($pf{dacg45}<0.8) { $color=16711680; }
                  if ($pf{dacg45}<0.6) { $color=16740416; }
                  if ($pf{dacg45}<0.4) { $color=255; }
                  if ($pf{dacg45}<0.2) { $color=65280; }
                  return "Pen ($width,2,$color)";
                 },
   },
  regional =>
   { fichiers => 'regional',
     table    => 'comroute',
     colonnes => [['comroute','char',16,''],
                  ['insee','char',5,''],
                  ['route','char',10,''],
                  ['agg45','char',16,''],
                  ['vocation','char',20,''],
                  ['longueur','float','',''],
                  ['nbacc','integer','',''],
                  ['nbacg','integer','',''],
                  ['nbacm','integer','',''],
                  ['nbbl','integer','',''],
                  ['nbbg','integer','',''],
                  ['nbtue','integer','',''],
                  ['dacg','float','',''],
                  ['dacg45','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
     critere  => "vocation='Type autoroutier' or vocation='Liaison principale' or vocation='Liaison regionale'",
     repgraf  => sub {
                  my %pf = @_;
                  my $width=3;
                  if ($pf{vocation} eq 'Liaison r�gionale') { $width=2; }
                  my $color=0;
                  if ($pf{dacg45}<0.8) { $color=16711680; }
                  if ($pf{dacg45}<0.6) { $color=16740416; }
                  if ($pf{dacg45}<0.4) { $color=255; }
                  if ($pf{dacg45}<0.2) { $color=65280; }
                  return "Pen ($width,2,$color)";
                 },
   },
  local =>
   { fichiers => 'local',
     table    => 'comroute',
     colonnes => [['comroute','char',16,''],
                  ['insee','char',5,''],
                  ['route','char',10,''],
#                  ['agg45','char',16,''],
                  ['vocation','char',20,''],
                  ['longueur','float','',''],
                  ['nbacc','integer','',''],
                  ['nbacg','integer','',''],
                  ['nbacm','integer','',''],
                  ['nbbl','integer','',''],
                  ['nbbg','integer','',''],
                  ['nbtue','integer','',''],
                  ['dacg','float','',''],
                  ['url','char','200',''],
#                  ['dacg45','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
     repgraf  => sub {
                  my %pf = @_;
                  my $width=2;
#                  if ($pf{vocation} eq 'Liaison locale') { $width=1; }
                  my $color=0;
                  if ($pf{dacg}<0.8) { $color=16711680; }
                  if ($pf{dacg}<0.6) { $color=16743504; }
                  if ($pf{dacg}<0.4) { $width=1; $color=5079040; }
                  if ($pf{dacg}<0.2) { $width=1; $color=65280; }
                  return "Pen ($width,2,$color)";
                 },
   },
  trdacg =>
   { fichiers => 'trdacg',
     select   => 'select Id_Route500, Vocation, Numero_Route,
                         Longueur_Troncon, nbacg/Longueur_Troncon, astext(geom)
                  from tr500 left join trnbacg on Id_Route500=idtr',
     colonnes => [['Id_Route500','integer','',''],
                  ['Vocation','char',18,''],
                  ['Route','char',10,''],
                  ['Longueur','decimal',6,2],
                  ['dacg','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
     repgraf  => sub {
                  my %pf = @_;
                  if (! $pf{Route})
                  { return "Pen (1,2,0)";
                  }
                  my $width=2;
                  my $color=0;
                  if ($pf{dacg}<0.8) { $color=16711680; }
                  if ($pf{dacg}<0.6) { $color=16740416; }
                  if ($pf{dacg}<0.4) { $color=255; }
                  if ($pf{dacg}<0.2) { $color=65280; }
                  return "Pen ($width,2,$color)";
                 },
   },
  sansnom =>
   { fichiers => 'sansnom',
     table    => 'tr500',
     critere  => "Numero_Route=''",
     colonnes => [['Id_Route500','integer','',''],
                  ['Vocation','char',18,''],
                  ['Longueur_Troncon','decimal',6,2],
                  ['geom','GeometryCollection','',''],
                 ],
     repgraf  => sub {
                  return "Pen (1,2,12632256)";
                 },
   },
  comroute =>
   { fichiers => 'comroute',
     table    => 'comroute',
     colonnes => [['comroute','char',16,''],
                  ['insee','char',5,''],
                  ['route','char',10,''],
                  ['vocation','char',20,''],
                  ['longueur','float','',''],
                  ['geom','GeometryCollection','',''],
                 ],
   },
  aireurbaine =>
   { fichiers => 'aireurbaine',
     select   => "select a.nom, astext(c.geom)
                  from com500 c, ncom500 n, com_aireurbaine ca, aireurbaine a
                  where c.Id_Route500=n.Id_Route500 and INSEE_Commune=ca.com and ca.aire=a.aire",
     colonnes => [['nom','char','40',''],
                  ['geom','GeometryCollection','',''],
                 ],
   },
);

my $database = "DBI:mysql:geo";       # nom de la base dans MySQL
my $user = "root";                    # login dans MySQL
my $verbose = 0;
my $nbmax = 0;

use DBI;

if (@ARGV)
{ foreach my $param (@ARGV)
  { if (! exists $parametres{$param})
    { print "ERREUR: parametre $param inconnu\n";
      next;
    }

    print ("Generation de $param\n");
    my $FMIF = '>'.$parametres{$param}{fichiers}.'.MIF';
    open FMIF, $FMIF or die "Ouverture du fichier $FMIF impossible : $!\n";

    my $FMID = '>'.$parametres{$param}{fichiers}.'.MID';
    open FMID, $FMID or die "Ouverture du fichier $FMID impossible : $!\n";

    my %Entete = (
      'CoordSys'    => CoordSys('Lambert II carto Paris'),
      'Columns'     => $parametres{$param}{colonnes},
      'Delimiter' => ';',
    );

    print FMIF Entete2Mif(\%Entete),"\n";

    print "Schema MIF/MID:\n";
    foreach my $col (@{$parametres{$param}{colonnes}})
    { print '  ',$$col[0],' ',$$col[1];
      if ($$col[3] ne '') { print ' (',$$col[2],',',$$col[3],')'; }
      elsif ($$col[2] ne '') { print ' (',$$col[2],')'; }
      print "\n";
    }
    my $sta = $parametres{$param}{select};
    if (! $sta)
    { $sta = 'SELECT';
      foreach my $col (@{$parametres{$param}{colonnes}})
      { if ($$col[1] ne 'GeometryCollection')
        { $sta .= ' '.$$col[0].',';
        }
        else
        { $sta .= ' astext('.$$col[0].'),';
        }
      }
      $sta =~ s/,$//;
      $sta .= " \n".'FROM '.$parametres{$param}{table};
      if (exists($parametres{$param}{critere}))
      { $sta .= " \n".'WHERE '.$parametres{$param}{critere};
      }
    }
    print "Requete: \n$sta\n";
#  if ($verbose) { print "$sta\n"; }
    my $dbh = DBI->connect ($database, $user);
    my $sth = $dbh->prepare($sta) or die "Can't prepare $sta: ".$dbh->errstr; 
    my $rv = $sth->execute or die "can't execute the query: " . $sth->errstr;
    my $nbobj=0;
    while (my @row = $sth->fetchrow_array())
    { my $mid='';
      foreach my $ncol (0.. $#{@{$parametres{$param}{colonnes}}})
      { if ($parametres{$param}{colonnes}[$ncol][1] eq 'GeometryCollection')
        { my %geom = Wkt2Geom($row[$ncol]); 
          print FMIF Geom2Mif(\%geom);
        }
        elsif ($parametres{$param}{colonnes}[$ncol][1] eq 'char')
        { $mid .= '"'.$row[$ncol].'"'.$Entete{Delimiter};
        }
        else
        { $mid .= $row[$ncol].$Entete{Delimiter};
        }
      }
      $mid =~ s/;$//;
      print FMID $mid,"\n";
      if (exists $parametres{$param}{repgraf})
      { my %pf;
        foreach my $ncol (0.. $#{@{$parametres{$param}{colonnes}}})
        { $pf{$parametres{$param}{colonnes}[$ncol][0]} = $row[$ncol];
        }
        my $repgraf = $parametres{$param}{repgraf};
        my $mif = &$repgraf(%pf);
        print FMIF $mif."\n";
      }
      $nbobj++;
    }
    close(FMIF);
    close(FMID);
    $dbh->disconnect(); 
    print "$nbobj objets ecrits dans $FMIF et $FMID\n";
  }
}
else
{ print "usage: perl gemifmid.pl <param> <param> ...\n";
  print "Liste des parametres admis:\n";
  foreach my $param (keys %parametres)
  { print " ",$param," -> ", $parametres{$param}{fichiers}, ".MIF/MID\n";
  }
}
package Geom;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(eqliste StartPoint EndPoint Retourne Longueur EstFerme Surface PointDansPolygone InterSegSeg chpts
             GeometryType VerifieIntegrite AfficheGeom Boundrect PointInRect PointInRects SupRects Dilate Ecart 
             LitFichierMifMid exemple_dappel_LitFichierMifMid
             LongueurLineString SurfacePolygon AggLineString PointDansMultipolygone
             IntersSegMPolygon IntersMLineStringMPolygon
             StructureGeom Geom2Wkt Wkt2Geom Geom2Mif CoordSys Entete2Mif
             Tests_non_regression);
@EXPORT_OK = qw($ident @Tests_non_regression);

#   0         1         2         3         4         5         6         7         8         9         0
# 34567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012

use strict;

my $ident = "Geom - Package de gestion d'objets geomatiques - Benoit DAVID - 9/5/09 21:00";

my $Historique = <<FIN_HISTORIQUE
9/2/2010
----------
 - ajout de la definition du Lambert93

9/5/2009
----------
 - ajout de la fonction SurfacePolygon

2/5/2009
----------
 - corrections dues au passage de indigoperl a ActivePerl 5.10
 - pbs sur la notation '(d)#{(a)x}' remplacee par '(a)x-1'

30/12/2008
----------
 - correction d'un bug dans getmid sur lecture d'un nombre en format e-<dd> ou e+<dd> dans un decimal ou un flottant

15/3/2008
----------
 - modification de StructureGeom pour eviter une erreur lors du traitement de geometries incorrectes
   comme par exemple l'existence de la meme boucle 2 fois ou 1 point commun entre 2 boucles

19/11/2007
----------
 - modification de getmid pour prendre en compte la possibilite que le champ contienne un double guillemet
 - modification de LitFichierMifMid pour prendre en compte la possibilite d'un symbole avec une police TrueType
 - modification de LitFichierMifMid pour prendre en compte la possibilite du parametre Smooth

3/8/2007
----------
 - correction d'un bug dans Geom2Mif

2/1/2007
----------
 - ajout des projections UTM20N, UTM22N et UTM40S

29/12/2006
----------
 - ajout dans LitFichierMifMid la possibilite d'avoir un Brush avec seulement 2 parametres

22/10/2005
---------
 - remplacement des parametres de 'Lambert II carto Paris' par celles de la versions 7.8
 - les parametres d'avant restent accessibles sous le nom 'Lambert II carto Paris (<=7.5)'

1/10/2005
---------
 - ajout dans LitFichierMifMid de lire une coordonnee cod�e sous la forme 2.5e-5

22/6/2005
---------
 - correction d'un bug dans constructionListeSegments

8/6/2005
--------
 - Ajout de SupRects

25/1/2005
--------
 - Ajout de PointInRect et PointInRects

11/1/2005
--------
 - Ajout de Boundrect et Dilate

5-10/1/2005
--------
 - Recriture et tests de MLineStringMPolygon

3/1/2005
--------
 - modification de getmid et LitFichierMifMid pour prendre en compte le delimiteur par defaut \t

2/1/2005
--------
 - reecriture inters.pl, ajout dans Geom des fonctions AggLineString et IntersMLineStringMPolygon
 - Ajout du type LinearRing
 - Insertion d'un mecanisme systematique de tests de non regression

1/1/2005
--------
 - 1ere version du package
FIN_HISTORIQUE
;

my $Bugs_connus = "
 - dans InterSegSeg, l'intersection de deux segments paralleles est consideree comme negative
 - dans IntersMLineStringMPolygon un cas teste dans les tests de non regression fait une erreur,
   il s'agit du cas ou un point intermediaire se trouve sur un segment ou sur un point intermediaire
   de l'autre objet. Un contournement consiste a ajouter .1 sur l'une des 2 couches.
";

my $Reste_a_faire = "
 - Ajouter la demi-distance de Hausdorff entre Geom
 - Mettre des prototypes aux fonctions
 - Separer le package en 2, l'un pour les utilitaires fonctions geometriques simples, l'autre
   autour de la structure Geom
 - Simplifier le code:
   - de litfichiermifmid en utilisant chop pour supprimer le \n a la fin de la ligne
   - de getmid en utilisant split
 - Finir l'ajout d'un test permanent de non regression du package
 - Ajout de la possibilite de gerer les longueurs et surface terrain dans la structure Geom
 - Traitement des collections
 - traitement des WFS
";

# Enregistrement des tests a effectuer pour chaque fonction
my @Tests_non_regression;

# ============
# Utilitaires
# ============
# Test d'egalite entre deux listes
# ----------
sub eqliste
# ----------
{ my ($a, $b) = @_;
  my @a = (@$a);
  my @b = (@$b);
  if (scalar(@a) != scalar(@b))
  { return 0;
  }
  while(scalar(@a))
  { if (pop(@a) ne pop(@b))
    { return 0;
    }
  }
  return 1;
}

# ========================================
# Quelques fonctions geometriques simples
# Sauf indique, ces fonctions prennent en parametre une liste de points
# codee sous la forme d'une liste de x,y.
# Par convention dans les calculs d'intesection, les segments sont generalement semi-fermes,
# c'est a dire que le premier point appartient au segment mais que le second n'y appartient pas.
# ========================================
# Premier point
# ----------
sub StartPoint { return @_[0..1]; }

push @Tests_non_regression, 'StartPoint', sub
  { my @lpt = (0,5, 1,4, 2,3);
    my @spt = StartPoint(@lpt);
    if (! eqliste(\@spt, [0,5]))
    { die "Erreur dans le test de regression de StartPoint";
    }
  };

# Dernier point
# ----------
sub EndPoint { return @_[-2 .. -1]; }

push @Tests_non_regression, 'EndPoint', sub
  { my @ept = EndPoint(0,5, 1,4, 2,3);
    if (! eqliste(\@ept, [2,3]))
    { die "Erreur dans le test de regression de EndPoint";
    }
  };

# Tous les points sauf le premier
# ----------
sub Reste { return @_[2 .. @_-1]; }

push @Tests_non_regression, 'Reste', sub
  { my @rpt = Reste(0,0, 1,1, 2,2);
    if (! eqliste(\@rpt, [1,1, 2,2]))
    { die "Erreur dans le test de regression de Reste";
    }
  };

# la meme liste de points dans l'autre sens
# ----------
sub Retourne
# ----------
{ my @res = ();
  while (@_)
  { my $y = pop @_;
    my $x = pop @_;
    push @res, $x, $y
  }
  return @res;
}

push @Tests_non_regression, 'Retourne', sub
  { my @ret = Retourne(0,1, 1,3, 2,4);
    if (! eqliste(\@ret, [2,4, 1,3, 0,1]))
    { die "Erreur dans le test de regression de Retourne";
    }
  };

# Test de fermeture d'une polyligne
# --------------------
sub EstFerme { return (($_[-1] == $_[1]) and ($_[-2] == $_[0])); }

push @Tests_non_regression, 'EstFerme', sub
  { my @lpt = (0,1, 1,3, 2,4, 0,1);
    if (! EstFerme(@lpt))
    { die "Erreur dans le test de regression de EstFerme";
    }
    if (EstFerme(Reste(@lpt)))
    { die "Erreur dans le test de regression de EstFerme";
    }
  };

# calcul du produit vectoriel de deux vecteurs A et B (2D -> scalaire)
# --------------------
sub pvect
# --------------------
{ my ($xa, $ya, $xb, $yb) = @_;
  return $xa * $yb - $ya * $xb;
}

push @Tests_non_regression, 'pvect', sub
  { if  ((pvect (1,0, 0,1) != 1)
      or (pvect (0,1, 0,9) != 0))
    { die "Erreur dans le test de regression de pvect";
    }
  };

# calcul du produit scalaire de deux vecteurs A et B (2D -> scalaire)
# --------------------
sub pscal
# --------------------
{ my ($xa, $ya, $xb, $yb) = @_;
  return $xa * $xb + $ya * $yb;
}

push @Tests_non_regression, 'pscal', sub
  { if  ((pscal (1,0, 0,1) != 0)
      or (pscal (0,1, 0,9) != 9))
    { die "Erreur dans le test de regression de pscal";
    }
  };

# Norme d'un vecteur
# ----------
sub Norme
# ----------
{ return sqrt ($_[0]**2 + $_[1]**2);
}

push @Tests_non_regression, 'Norme', sub
  { if  ((Norme(0,1) != 1)
      or (Norme(1,0) != 1))
    { die "Erreur dans le test de regression de Norme";
    }
  };

# Longueur d'une polyligne
# ----------
sub Longueur
# ----------
{ my $lon = 0;
  foreach my $n (1 .. ($#_-1)/2)
  { my $dx = $_[2*$n] - $_[2*$n-2];
    my $dy = $_[2*$n+1] - $_[2*$n-1];
    $lon += sqrt($dx*$dx + $dy*$dy);
  }
  return $lon;
}

push @Tests_non_regression, 'Longueur', sub
  { my @lpt = (0,1, 1,1, 1,4, 0,4);
    if (Longueur(@lpt) != 5)
    { die "Erreur dans le test de regression de Longueur";
    }
  };

# Surface d'un polygone
# ---------
sub Surface
# ---------
{ my $surf = 0;
  foreach my $n (2 .. ($#_-1)/2)
  { $surf += ($_[2*$n-2] - $_[0]) * ($_[2*$n+1] - $_[1]) - ($_[2*$n] - $_[0]) * ($_[2*$n-1] - $_[1]);
  }
  return $surf/2;
}

push @Tests_non_regression, 'Surface', sub
  { my @lpt = (0,0, 10,0, 0,10, 0,0);
    if (Surface(@lpt) != 50)
    { die "Erreur dans le test de regression de Surface";
    }
  };

# Calcule le rectangle englobant d'une liste de points sous la forme d'une liste des points min et max
# ---------
sub BoundrectPts
# ---------
{ if (@_ < 2) { return; }
  my @min = @_[0..1];
  my @max = @_[0..1];
  for my $n (1 .. (@_/2)-1)
  { if ($min[0] > $_[2*$n])
    { $min[0] = $_[2*$n];
    }
    if ($min[1] > $_[2*$n+1])
    { $min[1] = $_[2*$n+1];
    }
    if ($max[0] < $_[2*$n])
    { $max[0] = $_[2*$n];
    }
    if ($max[1] < $_[2*$n+1])
    { $max[1] = $_[2*$n+1];
    }
  }
  return (@min, @max);
}

push @Tests_non_regression, 'BoundrectPts', sub
  { my @pts = (2,1, 4,3, 0,5);
    my @br = BoundrectPts(@pts);
    print join(' ',@pts),' -> ',join(' ',@br),"\n";
    if (!eqliste(\@br,[0,1, 4,5]))
    { die "Erreur dans le test de regression de BoundrectPts";
    }
  };

# Distance du premier point aux autres points de la liste
# Retourne le no du point qui correspond � la distance minimum et la distance 
# ------------------------
sub DistancePointPoints
# ------------------------
{ my ($x, $y, @pts) = @_;
  my $dmin = undef;
  my $n_dist;
  for my $n (0 .. (@pts/2)-1)
  { my $d = Norme($x-$pts[2*$n], $y-$pts[2*$n+1]);
    if ((!defined $dmin) or ($d < $dmin))
    { $dmin = $d;
      $n_dist = $n;
    }
  }
  print "DistancePointPoints -> $n_dist, $dmin\n";
  return ($n_dist, $dmin);
}
  
push @Tests_non_regression, 'DistancePointPoints', sub
  { my @tab = DistancePointPoints(0,0,  5,-4, 0,1, 1,-1, 1,8);
    print "DistancePointPoints=",join(' ',@tab),"\n";
    if (!eqliste(\@tab, [1, 1]))
    { die "Erreur dans le test de regression de DistancePointPoints";
    }
  };

# Distance signee d'un point P a une droite orientee definie par 2 points A et B
# la distance est positive si P est a gauche de la droite AB et negative si le point est a droite
# Les parametres sont les 3 points P, A, B
# La fonction retourne cette distance.
# --------------------
sub DistancePointDroite
# --------------------
{ my @ab = (@_[4] - @_[2], @_[5] - @_[3]); # vecteur B-A
  my @ap = (@_[0] - @_[2], @_[1] - @_[3]); # vecteur P-A
  return pvect (@ab, @ap) / Norme(@ab);
}

push @Tests_non_regression, 'DistancePointDroite', sub
  { if  ((DistancePointDroite( 0,9, 0,0, 1,0) != 9)
      or (DistancePointDroite(0,-9, 0,0, 1,0) != -9)
      or (DistancePointDroite( 0,0, 0,9, 0,10) != 0)
      or (DistancePointDroite( 7,0, 0,9, 0,10) != -7)
      or (DistancePointDroite(-7,0, 0,9, 0,10) != 7))
    { die "Erreur dans le test de regression de DistancePointDroite";
    }
  };

# Projection P' d'un point P sur une droite A,B
# Les parametres sont les 3 points P, A, B
# Renvoit u / P' = A + u * (B-A).
# Le point projete est sur le segment ssi u est dans [0 .. 1].
# -----------------------
sub ProjectionPointDroite
# -----------------------
{ my @ab = (@_[4] - @_[2], @_[5] - @_[3]); # vecteur B-A
  my @ap = (@_[0] - @_[2], @_[1] - @_[3]); # vecteur P-A
  return pscal(@ab, @ap)/(@ab[0]**2 + @ab[1]**2);
}

push @Tests_non_regression, 'ProjectionPointDroite', sub
  { if  ((ProjectionPointDroite( 0,0, 0,0, 7,0) != 0)
      or (ProjectionPointDroite( 4,9, 4,0, 7,0) != 0)
      or (ProjectionPointDroite(7,-9, 4,0, 7,0) != 1)
      or (ProjectionPointDroite(-8,6, 0,2, 0,10) != .5)
      or (ProjectionPointDroite(-7,0, 0,2, 0,10) != -.25))
    { die "Erreur dans le test de regression de ProjectionPointDroite";
    }
  };

# Distance (non signee) du point � la polyligne definie par une liste de points
# Retourne le point qui correspond � la distance et la distance 
# ------------------------
sub DistancePointPolyligne
# ------------------------
{ my ($x, $y, @pline) = @_;
  my $dmin = Norme($x - $pline[0], $y - $pline[1]);
  my @pmin = @pline[0 .. 1];
  for my $n (1 .. (@pline/2)-1)
  { my $u = ProjectionPointDroite($x, $y, @pline[2*$n-2 .. 2*$n+1]);
    if ($u < 0)
    { my $d = Norme($x-$pline[2*$n-2], $y-$pline[2*$n-1]);
      if ($d < $dmin)
      { $dmin = $d;
        @pmin = ($pline[2*$n-2], $pline[2*$n-1]);
      }
    }
    elsif ($u > 1)
    { my $d = Norme($x-$pline[2*$n], $y-$pline[2*$n+1]);
      if ($d < $dmin)
      { $dmin = $d;
        @pmin = ($pline[2*$n], $pline[2*$n+1]);
      }
    }
    else
    { my $d = abs(DistancePointDroite($x, $y, $pline[2*$n-2], $pline[2*$n-1], $pline[2*$n], $pline[2*$n+1]));
      if ($d < $dmin)
      { $dmin = $d;
        @pmin = ($pline[2*$n-2] + $u*($pline[2*$n  ]-$pline[2*$n-2]),
                 $pline[2*$n-1] + $u*($pline[2*$n+1]-$pline[2*$n-1]));
      }
    }
  }
#  print "DistancePointPolyligne -> ",join(' ',@pmin),", $dmin\n";
  return (@pmin, $dmin);
}
  
push @Tests_non_regression, 'DistancePointPolyligne', sub
  { my @tab = DistancePointPolyligne(0,0,   0,-2, 1,-1, 1,1);
    print "DistancePointPolyligne=",join(' ',@tab),"\n";
    if (!eqliste(\@tab, [1,0, 1]))
    { die "Erreur dans le test de regression de DistancePointPolyligne";
    }
  };

# Distance du segment � la polyligne definie par une liste de points
# Retourne le point qui correspond � la distance et la distance 
# ==================== Algorithme a verifier ===================
# ------------------------
sub DistanceSegPolyligne
# ------------------------
{ my ($x0, $y0, $x1, $y1, @pline) = @_;
  my $dmin = DistancePointPolyligne ($x0, $y0, @pline);
  my $d = DistancePointPolyligne ($x1, $y1, @pline);
  if ($d < $dmin)
  { $dmin = $d;
  }
  for my $n (1 .. (@pline/2)-1)
  { my @seg = @pline[2*$n-2 .. 2*$n+1];
    if (InterSegSeg (\@seg, [$x0, $y0, $x1, $y1]))
    { return 0;
    }
  }
  return $dmin;
}
  
push @Tests_non_regression, 'DistanceSegPolyligne', sub
  { print "DistanceSegPolyligne=",DistanceSegPolyligne(3,5, 3,20,   0,10, 0,0, 10,0, 10,10),"\n";
    if (DistanceSegPolyligne(3,5, 3,20,   0,10, 0,0, 10,0, 10,10) != 3)
    { die "Erreur dans le test de regression de DistanceSegPolyligne";
    }
    if (DistanceSegPolyligne(3,-5, 3,20,   0,10, 0,0, 10,0, 10,10) != 0)
    { die "Erreur dans le test de regression de DistanceSegPolyligne";
    }
  };

# Teste si un point est dans un polygone
# Les 2 premiers parametres sont les coordonnes du point
# les autres forment le tableau des x,y du polygone, le polygone doit etre ferme
# le retour vaut 1 en cas d'inclusion et 0 sinon
# --------------------
sub PointDansPolygone
# --------------------
{ my ($x, $y, @pol) = @_;
  my $code_de_reference_en_C ="
    int pnpoly(int npol, float *xp, float *yp, float x, float y)
    {
      int i, j, c = 0;
      for (i = 0, j = npol-1; i < npol; j = i++) {
        if ((((yp[i]<=y) && (y<yp[j])) ||
             ((yp[j]<=y) && (y<yp[i]))) &&
            (x < (xp[j] - xp[i]) * (y - yp[i]) / (yp[j] - yp[i]) + xp[i]))

          c = !c;
      }
      return c;
    }
  ";
# npol = @pol/2
  my ($i, $j, $c) = (0, 0, 0);
  for (my $i=0, my $j=(@pol/2)-1; $i < (@pol/2); $j = $i++)
  { if (((($pol[2*$i+1] <= $y) and ($y < $pol[2*$j+1])) or
         (($pol[2*$j+1] <= $y) and ($y < $pol[2*$i+1]))) and
        ($x < ($pol[2*$j] - $pol[2*$i]) * ($y - $pol[2*$i+1]) / ($pol[2*$j+1] - $pol[2*$i+1]) + $pol[2*$i]))
    { $c = 1 - $c;
    }
  }
  return $c;
}

push @Tests_non_regression, 'PointDansPolygone', sub
  { my @pol = (0,0, 10,0, 0,10, 0,0);
    if  ((!PointDansPolygone(2,2, @pol))
      or (PointDansPolygone(9,9, @pol)))
    { die "Erreur dans le test de regression de PointDansPolygone";
    }
  };

# calcul de l'intersection entre 2 segments a et b
# chaque segment est un pointeur sur un tableau de 4 nombres (x0, y0, x1, y1)
# Si l'intersection existe alors le retour de la fonction est le tableau  (x, y, u, v)
# Renvoit () sinon
# --------------------
sub InterSegSeg
# --------------------
{ my ($a, $b) = @_;
  my @va  = ($$a[2]-$$a[0], $$a[3]-$$a[1]); # le vecteur correspondant au segment A
  my @vb  = ($$b[2]-$$b[0], $$b[3]-$$b[1]); # le vecteur correspondant au segment B
  my @vab = ($$b[0]-$$a[0], $$b[1]-$$a[1]); # le vecteur du debut de B - le debut de A
  my $pab = pvect(@va, @vb);
  if ($pab == 0)
  { if (pvect(@vab, @va) == 0)
    {# die "droites confondues";
# Simplification dans ce cas
      return ();
    }
    else
    {# print "// -> non\n";
      return ();
    }
  }
  else
  { my $u = pvect(@vab, @vb) / $pab;
    my $v = pvect(@vab, @va) / $pab;
#    print ", u=$u, v=$v";
    if (($u >= 0) and ($u < 1) and ($v >= 0) and ($v < 1))
    {
#      print " -> oui\n";
      return ( $$a[0] + $u * $va[0],
               $$a[1] + $u * $va[1],
               $u,
               $v);
    }
    else
    {# print " -> non\n";
      return ();
    }
  }
}

push @Tests_non_regression, 'InterSegSeg', sub
  { my 
    @res = InterSegSeg([0,0, 1,0], [0,0, 0,1]);
    if (!eqliste(\@res,[0,0,0,0]))
    { die "Erreur dans le test de regression de InterSegSeg";
    }
    @res = InterSegSeg([-1,0, 1,0], [0,-1, 0,1]);
    if (!eqliste(\@res,[0,0,0.5,0.5]))
    { die "Erreur dans le test de regression de InterSegSeg";
    }
    @res = InterSegSeg([0,0, 1,1], [0,1, 1,0]);
    if (!eqliste(\@res,[0.5,0.5,0.5,0.5]))
    { die "Erreur dans le test de regression de InterSegSeg";
    }
    @res = InterSegSeg([0,0, 1,1], [1,0, 2,1]);
    if (!eqliste(\@res,[]))
    { die "Erreur dans le test de regression de InterSegSeg";
    }
    @res = InterSegSeg([0,0, 1,1], [2,2, 3,3]);
    if (!eqliste(\@res,[]))
    { die "Erreur dans le test de regression de InterSegSeg";
    }
  };

# Fabrique la chaine correspondant � l'affichage d'une liste de points 
# si le premier parametre est vrai
# --------------------
sub chpts
# --------------------
{ my ($bool, @ppt) = @_;
  my $chaine='';
  if ($bool)
  { my $x=1;
    foreach my $c (@ppt)
    { $chaine .= $c;
      if ($x) { $chaine .= ' '; } else { $chaine .= ','; }
      $x = 1 - $x;
    }
    $chaine =~ s/,$//;
  }
  return $chaine;
}

push @Tests_non_regression, 'chpts', sub
  { if (chpts(1, 0,1, 1,1, 1,4, 0,4) ne '0 1,1 1,1 4,0 4')
    { die "Erreur dans le test de regression de chpts";
    }
  };

# ==================================================
# Manipulation des objets geomatiques
# ==================================================
# Ce package utilise des structures de donn�es specifiques pour traiter les composantes 
# geometrique et graphique d'un objet geographique : elles sont gerees sous la forme d'un
# hachage contenant les champs suivants:
#   P : la partie ponctuelle, definie comme un ensemble de points et representee par un 
#       pointeur vers un tableau de x, y
#   L : la partie lineaire, definie comme un ensemble de lignes brisees et representee par
#       un pointeur sur un tableau de lignes, chacune representee par un pointeur vers 
#       un tableau de x, y
#   S : la partie surfacique structuree (a la OGC), definie comme un ensemble de polygones 
#       et representee par un pointeur sur un tableau de polygones, chacun represente par
#       un pointeur vers un tableau de contours, chacun represente par un pointeur vers un
#       tableau de x, y ; le premier contour est l'exterieur et les autres sont des interieurs  
#   R : la partie surfacique mise a plat (a la MapInfo), definie comme un ensemble de 
#       polygones et representee par un pointeur sur un tableau de polygones, chacun 
#       represente par un pointeur vers des tableau de x, y. Les exterieurs et les interieurs
#       sont melanges. Cette forme R est normalement temporaire.
#   Rect : un rectangle defini par 2 coins opposes represente par un pointeur vers un tableau de x, y
#   RoundRect : un rectangle arrondi defini par 2 coins opposes represente par un pointeur vers un 
#       tableau des 2 couples de x, y suivis du degre d'arrondi
#   Ellipse : une ellipse definie par 2 coins opposes du rectangle englobant represente par un 
#       pointeur vers un tableau de x, y
#   Arc : une arc d'ellipse definie par 2 coins opposes du rectangle englobant et 2 angles 
#       represente par un pointeur vers un tableau des 2 couples de x, y suivis des 2 angles
#   Pen : un pointeur vers un tableau de 3 entiers : width, pattern, color
#   Brush : un pointeur vers un tableau de 2 ou 3 entiers : pattern, forecolor [, backcolor ]
#   Symbol : un pointeur vers un tableau de 3 entiers : shape, color, size
#   Center : un pointeur vers un tableau x, y
# Ce hachage ou un pointeur sur ce hachage est appelle geom.

# L'en-tete du fichier MIF est un hachage contenant les champs suivants:
#   CoordSys : la chaine du fichier MIF definissant le systeme de coordonnees
#   Columns : un pointeur sur le tableau des colonnes, chaque colonne est definie par un pointeur
#       vers un tableau d'elements: le nom, le type et les parametres eventuels.
#   ColumnNames : un pointeur vers un hachage donnant pour chaque nom de colonne son numero a partir de 0

# La composante alphanumerique est geree sous la forme d'un tableau de valeurs.
# ==================================================

# Verifie l'integrite d'un geom
# Renvoit vrai ssi l'integrite est verifiee
# --------------------
sub VerifieIntegrite
# --------------------
{ my ($geom) = @_;

# Verification de la cloture des polygones
  if (${$geom}{R})
  { foreach my $ppt (@{${$geom}{R}})
    { if (!EstFerme(@{$ppt}))
      { print "Erreur de cloture d'un polygone\n";
        return 0;
      }
    }
  }
  if (${$geom}{S})
  { foreach my $polyg (@{${$geom}{S}})
    { foreach my $ppt (@{$polyg})
      { if (!EstFerme(@{$ppt}))
        { print "Erreur de cloture d'un polygone\n";
          return 0;
        }
      }
    }
  }
  return 1;
}

# Fabrique le champ S a la place du champ R
# --------------------
sub StructureGeom
# --------------------
{ my ($geom) = @_;
#  print ">> StructureGeom\n";
  if (${$geom}{R})
  { my %inclusdans=();

# initialisation des surfaces des anneaux pour eviter de les recalculer
    my @surface;
    foreach my $nr (0.. @{${$geom}{R}} - 1)
    { $surface[$nr] = Surface(@{${${$geom}{R}}[$nr]});
    }

# calcul des inclusions d'un anneau dans un autre, le resultat sera dans %inclusdans
    foreach my $nrext (0 .. @{${$geom}{R}} - 1)
    { my @polext = @{${${$geom}{R}}[$nrext]};
      foreach my $nrint (0.. @{${$geom}{R}} - 1)
      { if ($nrint != $nrext)
        { my @ptint = @{${${$geom}{R}}[$nrint]}[0..1];
#          print "    nrint=$nrint -> ",join(' ',@ptint),",",join(' ',@polext),"\n";
# Modification du 15/3/2008: Afin d'eviter les inclusions reciproques, je rajoute la contrainte de surface
          if ((abs($surface[$nrint]) < abs($surface[$nrext])) and PointDansPolygone(@ptint,@polext))
          {
# Si $nrint est deja note comme inclus dans un anneau alors l'anneau englobant est celui dont la surface est minimum
            if (exists($inclusdans{$nrint}))
            { if (abs($surface[$nrext]) < abs($surface[$inclusdans{$nrint}]))
              {
#                print "  ---->  $nrint etait marque inclus dans ",$inclusdans{$nrint}," qui est remplace par $nrext\n";
                $inclusdans{$nrint} = $nrext;
              }
            }
            else
            { $inclusdans{$nrint} = $nrext;
#              print "  ---->  Boucle $nrint dans boucle $nrext\n";
            }
          }
        }
      }
    }
    
# Il peut y avoir des inclusions imbriquees, il faut calculer la profondeur pour chaque anneau
    my @profondeur;
    foreach my $nring (0 .. @{${$geom}{R}} - 1)
    { $profondeur[$nring]=0;
    }
    my $continuer = 1;
    my $watchdog=0;
    while ($continuer)
    { $continuer = 0;
      foreach my $nring (keys %inclusdans)
      { if ($profondeur[$nring] != $profondeur[$inclusdans{$nring}] + 1)
        {
#          print "Modification de la profondeur de $nring ->  ",$profondeur[$inclusdans{$nring}] + 1," au lieu de ",$profondeur[$nring],"\n";
          $profondeur[$nring] = $profondeur[$inclusdans{$nring}] + 1;
          $continuer = 1;
        }
      }
      if ($watchdog++ > 1000) { die "ERREUR de programmation";}
    }
# on supprime les inclusions pour lesquelles le trou est de profondeur paire
    foreach my $nring (keys %inclusdans)
    { if ($profondeur[$nring] % 2 == 0)
      {
#        print "Suppression du trou $nring de profondeur ",$profondeur[$nring]," inclus dans ",$inclusdans{$nring},"\n";
        delete $inclusdans{$nring};
      }
    }
# Je construis la composante S en prenant les contours exterieurs et en leur concatenant leurs interieurs
    foreach my $nrext (0.. @{${$geom}{R}} - 1)
    { if (! exists $inclusdans{$nrext})
      { push @{${$geom}{S}},[${${$geom}{R}}[$nrext]];
# tabint est un pointeur vers la table des contours cree par le [] precedent
        my $tabint = ${${$geom}{S}}[@{${$geom}{S}} - 1];
        foreach my $nrint (keys %inclusdans)
        { if ($inclusdans{$nrint} == $nrext)
          { push @{$tabint},${${$geom}{R}}[$nrint];
          }
        }
      }
    }
    delete ${$geom}{R};
  }
#  print "<< StructureGeom\n";
}


# Tableau des correspondances entre types geometriques Geom, MI et OGC
my %GeometryType =    #        MI,           OGC(WKT)
 ( 'Empty'              => ['',              ''],
   'Point'              => ['Point',         'POINT'],
   'Line'               => ['Line',          'LINESTRING'],
   'LineString'         => ['Pline',         'LINESTRING'],
   'LinearRing'         => ['Pline',         'LINESTRING'],
   'Arc'                => ['Arc',           ''],
   'Polygon'            => ['',              'POLYGON'],
   'Rectangle'          => ['Rect',          'POLYGON'],
   'RoundRectangle'     => ['RoundRect',     ''],
   'Ellipse'            => ['Ellipse',       ''],
   'MultiPoint'         => ['Multipoint',    'MULTIPOINT'],
   'MultiLineString'    => ['Pline Multiple','MULTILINESTRING'],
   'MultiPolygon'       => ['Region',        'MULTIPOLYGON'],
   'GeometryCollection' => ['Collection',    'GEOMETRYCOLLECTION'],
 );

# Fournit un type geometrique de type OGC etendu
# --------------------
sub GeometryType 
# --------------------
{ my ($geom) = @_;
  if (${$geom}{Rect})
  { return 'Rectangle';
  }
  elsif (${$geom}{RoundRect})
  { return 'RoundRectangle';
  }
  elsif (${$geom}{Ellipse})
  { return 'Ellipse';
  }
  elsif (${$geom}{Arc})
  { return 'Arc';
  }
  elsif ((exists ${$geom}{P}) and (!exists ${$geom}{L}) and (!exists ${$geom}{S}) and (!exists ${$geom}{R}))
  { if (@{${$geom}{P}} == 2)
    { return 'Point';
    }
    else
    { return 'MultiPoint';
    }
  }
  elsif ((!exists ${$geom}{P}) and (exists ${$geom}{L}) and (!exists ${$geom}{S}) and (!exists ${$geom}{R}))
  { if (@{${$geom}{L}}>1)
    { return 'MultiLineString';
    }
    elsif (@{${${$geom}{L}}[0]} == 4)
    { return 'Line';
    }
    elsif (EstFerme(@{${${$geom}{L}}[0]}))
    { return 'LinearRing';
    }
    else
    { return 'LineString';
    }
  }
  elsif ((!exists ${$geom}{P}) and (!exists ${$geom}{L}) and ((exists ${$geom}{S}) or (exists ${$geom}{R})))
  { if ((exists ${$geom}{S}) and (@{${$geom}{S}} == 1))
    { return 'Polygon';
    }
    elsif ((exists ${$geom}{R}) and (@{${$geom}{R}} == 1))
    { return 'Polygon';
    }
    else
    { return 'MultiPolygon';
    }
  }
  elsif (((exists ${$geom}{P}) and (exists ${$geom}{L}))
      or ((exists ${$geom}{L}) and ((exists ${$geom}{S}) or (exists ${$geom}{R})))
      or ((exists ${$geom}{P}) and ((exists ${$geom}{S}) or (exists ${$geom}{R}))))
  { return 'GeometryCollection';
  }
  else
  { return 'Empty';
  }
}

push @Tests_non_regression, 'GeometryType', sub
  { if (GeometryType({Rect=>[0,0, 100,50]}) eq 'Rectangle')
    { print "OK sur Rect=>[0,0, 100,50]\n"; }
    else
    { die 'Erreur sur Rect=>[0,0, 100,50]'; }
    if (GeometryType({RoundRect=>[0,0, 100,50]}) eq 'RoundRectangle')
    { print "OK sur RoundRect=>[0,0, 100,50]\n"; }
    else
    { die 'Erreur sur RoundRect=>[0,0, 100,50]'; }
    if (GeometryType({Ellipse=>[0,0, 100,50]}) eq 'Ellipse')
    { print "OK sur Ellipse=>[0,0, 100,50]\n"; }
    else
    { die 'Erreur sur Ellipse=>[0,0, 100,50]'; }
    if (GeometryType({P=>[0,0]}) eq 'Point')
    { print "OK sur P=>[0,0]\n"; }
    else
    { die 'Erreur sur P=>[0,0]'; }
    if (GeometryType({P=>[0,0,1,1]}) eq 'MultiPoint')
    { print "OK sur P=>[0,0,1,1]\n"; }
    else
    { die 'Erreur sur P=>[0,0,1,1]'; }

    if (GeometryType({L=>[[0,0,1,1]]}) eq 'Line')
    { print "OK sur L=>[[0,0,1,1]]\n"; }
    else
    { die 'Erreur sur L=>[[0,0,1,1]]'; }
    if (GeometryType({L=>[[0,0,1,1],[0,0,1,1]]}) eq 'MultiLineString')
    { print "OK sur L=>[[0,0,1,1],[0,0,1,1]] -> ",GeometryType({L=>[[0,0,1,1],[0,0,1,1]]}),"\n"; }
    else
    { die 'Erreur sur L=>[[0,0,1,1],[0,0,1,1]]'; }
    if (GeometryType({L=>[[0,0,1,1,0,0]]}) eq 'LinearRing')
    { print "OK sur L=>[[0,0,1,1,0,0]] -> ",GeometryType({L=>[[0,0,1,1,0,0]]}),"\n"; }
    else
    { die 'Erreur sur L=>[[0,0,1,1,0,0]]'; }
    if (GeometryType({L=>[[0,0,1,1,2,2]]}) eq 'LineString')
    { print "OK sur L=>[[0,0,1,1,2,2]] -> ",GeometryType({L=>[[0,0,1,1,2,2]]}),"\n"; }
    else
    { die 'Erreur sur L=>[[0,0,1,1,2,2]]'; }

    if (GeometryType({S=>[[[0,0,1,0,1,1,0,0]]]}) eq 'Polygon')
    { print "OK sur S=>[[[0,0,1,0,1,1,0,0]]] -> ",GeometryType({S=>[[[0,0,1,0,1,1,0,0]]]}),"\n"; }
    else
    { die 'Erreur sur S=>[[[0,0,1,0,1,1,0,0]]]'; }
    if (GeometryType({R=>[[0,0,1,0,1,1,0,0]]}) eq 'Polygon')
    { print "OK sur R=>[[0,0,1,0,1,1,0,0]] -> ",GeometryType({R=>[[0,0,1,0,1,1,0,0]]}),"\n"; }
    else
    { die 'Erreur sur R=>[[0,0,1,0,1,1,0,0]]'; }
    if (GeometryType({S=>[[[0,0,1,0,1,1,0,0]],[[10,10,11,10,11,11,10,10]]]}) eq 'MultiPolygon')
    { print "OK sur S=>[[[0,0,1,0,1,1,0,0]],[[10,10,11,10,11,11,10,10]]] -> ",GeometryType({S=>[[[0,0,1,0,1,1,0,0]],[[10,10,11,10,11,11,10,10]]]}),"\n"; }
    else
    { die 'Erreur sur S=>[[[0,0,1,0,1,1,0,0]],[[10,10,11,10,11,11,10,10]]]'; }
  };

# Affichage d'un objet geometrique
# Les parametres sont les suivants:
#   verbose indique le niveau de verbosite'
#   noobj est le numero d'objet
#   mid est l'enregistrement du fichier .MID
#   objet est un pointeur sur une structure geometrique et graphique
#   mif est l'enregistrement du fichier .MIF
# --------------------
sub AfficheGeom 
# --------------------
{ my ($verbose, $noobj, $mid, $geom, $mif) = @_;
  my $gt = GeometryType($geom);
  print "Affiche_$gt ($noobj): ",join('|',@$mid),"\n";
  if (exists ${$geom}{P})
  { print "  Ponctuel: ",(@{${$geom}{P}}/2)," points: ",chpts($verbose>9,@{${$geom}{P}}),"\n";
  }
  if (exists ${$geom}{L})
  { print "  Lineaire: ",@{${$geom}{L}}+0," elts\n";
    foreach my $ppt (@{${$geom}{L}})
    { printf "    lon=%.2f, ",Longueur(@{$ppt});
      print @{$ppt}/2," pts: ",chpts($verbose>9,@{$ppt}),"\n";
    }
  }
  if (exists ${$geom}{R})
  { print "  Region: ",@{${$geom}{R}}+0," elts\n";
    foreach my $ppt (@{${$geom}{R}})
    { printf "    surf=%.2f, ",Surface(@{$ppt});
      print @{$ppt}/2," pts: ",chpts($verbose>9,@{$ppt}),"\n";
    }
  }
  if (exists ${$geom}{S})
  { print "  Surfacique: ",@{${$geom}{S}}+0," elts\n";
    my $nelt = 1;
    foreach my $polyg (@{${$geom}{S}})
    { print "   Element $nelt\n";
      foreach my $ppt (@{$polyg})
      { printf "    surf=%.2f, ",Surface(@{$ppt});
        print @{$ppt}/2," pts: ",chpts($verbose>9,@{$ppt}),"\n";
      }
      $nelt++;
    }
  }
  if (exists ${$geom}{Rect})
  { print "  Rectangle: ",chpts($verbose>9,@{${$geom}{Rect}}),"\n";
  }
  if (exists ${$geom}{RoundRect})
  { print "  Rectangle arrondi: ",chpts($verbose>9,@{${$geom}{RoundRect}}),"\n";
  }
  if (exists ${$geom}{Ellipse})
  { print "  Ellipse: ",chpts($verbose>9,@{${$geom}{Ellipse}}),"\n";
  }
  if (exists ${$geom}{Arc})
  { print "  Arc: ",chpts($verbose>9,@{${$geom}{Arc}}),"\n";
  }

  if (!VerifieIntegrite($geom))
  { print "ATTENTION, Objet geometrique non integre\n";
  }
  if (exists ${$geom}{Pen})
  { print "  Pen:{width=",${${$geom}{Pen}}[0],",pattern=",${${$geom}{Pen}}[1];
    my $color = ${${$geom}{Pen}}[2];
    print ",color:{red=",($color>>16)&0xFF,",green=",($color>>8)&0xFF,",blue=",$color&0xFF,"}}\n";
  }
  if (exists ${$geom}{Brush})
  { print "  Brush:{pattern=",${${$geom}{Brush}}[0];
    my $color = ${${$geom}{Brush}}[1];
    print ",forecolor:{red=",($color>>16)&0xFF,",green=",($color>>8)&0xFF,",blue=",$color&0xFF,"}";
    if (${${$geom}{Brush}}[2] == ${${$geom}{Brush}}[1])
    { print ",backcolor=forecolor}\n";
    }
    else
    { my $color = ${${$geom}{Brush}}[2];
      print ",backcolor:{red=",($color>>16)&0xFF,",green=",($color>>8)&0xFF,",blue=",$color&0xFF,"}\n";
    }
  }
  if (exists ${$geom}{Symbol})
  { print "  Symbol:{shape=",${${$geom}{Symbol}}[0];
    my $color = ${${$geom}{Symbol}}[1];
    print ",color:{red=",($color>>16)&0xFF,",green=",($color>>8)&0xFF,",blue=",$color&0xFF,"}";
    print ",size=",${${$geom}{Symbol}}[2],"}\n";
  }
  if (exists ${$geom}{Center})
  { print "  Center:{x=",${${$geom}{Center}}[0],",y=",${${$geom}{Center}}[1],"}\n";
  }
}

push @Tests_non_regression, 'AfficheGeom', sub
  { AfficheGeom(10,0,[],{Rect=>[0,0, 100,50]},'');
    AfficheGeom(10,0,[],{RoundRect=>[0,0, 100,50]});
    AfficheGeom(10,0,[],{Ellipse=>[0,0, 100,50]});
    AfficheGeom(10,0,[],{P=>[0,0]});
    AfficheGeom(10,0,[],{P=>[0,0,1,1]});
    AfficheGeom(10,0,[],{L=>[[0,0,1,1]]});
    AfficheGeom(10,0,[],{L=>[[0,0,1,1],[0,0,1,1]]});
    AfficheGeom(10,0,[],{L=>[[0,0,1,1,0,0]]});
    AfficheGeom(10,0,[],{L=>[[0,0,1,1,2,2]]});
    AfficheGeom(10,0,[],{S=>[[[0,0,1,0,1,1,0,0]]]});
    AfficheGeom(10,0,[],{R=>[[0,0,1,0,1,1,0,0]]});
    AfficheGeom(10,0,[],{S=>[[[0,0,1,0,1,1,0,0]],[[10,10,11,10,11,11,10,10]]]});
  };

# Calcule le rectangle englobant la geometrie
# --------------------
sub Boundrect
# --------------------
{ my %geom = @_;
  my @br;
  if (exists $geom{P})
  { @br = BoundrectPts(@br, @{$geom{P}});
  }
  if (exists $geom{L})
  { foreach my $ppt (@{$geom{L}})
    { @br = BoundrectPts(@br, @{$ppt});
    }
  }
  if (exists $geom{R})
  { foreach my $ppt (@{$geom{R}})
    { @br = BoundrectPts(@br, @{$ppt});
    }
  }
  if (exists $geom{S})
  { foreach my $polyg (@{$geom{S}})
    { foreach my $ppt (@{$polyg})
      { @br = BoundrectPts(@br, @{$ppt});
      }
    }
  }
  if (exists $geom{Rect})
  { @br = BoundrectPts(@br, @{$geom{Rect}});
  }
  if (exists $geom{RoundRect})
  { @br = BoundrectPts(@br, @{$geom{RoundRect}});
  }
  if (exists $geom{Ellipse})
  { die "Erreur: Boundrect non implemente pour l'ellipse";
  }
  if (exists $geom{Arc})
  { die "Erreur: Boundrect non implemente pour l'arc";
  }
  return (Rect=>[@br]);
}

push @Tests_non_regression, 'Boundrect', sub
  { my %geom = (P=>[6,3, 2,9, 4,7, 2,3]);
    AfficheGeom(10, 0, ['2 points'], \%geom, '');
    my %br = Boundrect(%geom);
    AfficheGeom(10, 0, ['le rectangle englobant'], \%br, '');
    if (!eqliste($br{Rect}, [2,3, 6,9]))
    { die "Erreur dans le test de regression de Boundrect";
    }
  };

# Teste l'inclusion d'un point dans un rectangle defini comme un geom
sub PointInRect
{ my ($x, $y, $rect) = @_;
#  print "PointInRect (x=$x, y=$y, xmin=$$rect{Rect}[0], ymin=$$rect{Rect}[1], xmax=$$rect{Rect}[2], ymax=$$rect{Rect}[3])\n";
  return (($x >= $$rect{Rect}[0]) and ($y >= $$rect{Rect}[1]) and ($x < $$rect{Rect}[2]) and ($y < $$rect{Rect}[3]));
}

# Teste l'inclusion d'un point dans une liste de rectangles, chacun defini comme un geom
sub PointInRects
{ my ($x, $y, @rects) = @_;
  foreach my $r (@rects)
  { if (PointInRect($x, $y, $r))
    { return 1;
    }
  }
  return 0;
}

# Calcule le plus petit rectangle engobant un ensemble de rectangles
sub SupRects
{ my (@rects) = @_;
  my @lpts;
  foreach my $r (@rects)
  { push @lpts, @{$$r{Rect}};
#    print join(' ',@lpts),"\n";
  }
  my @br = BoundrectPts(@lpts);
  return {Rect=>[@br]};
}

push @Tests_non_regression, 'SupRects', sub
  { my @rects = ({Rect=>[2,3, 6,9]}, {Rect=>[4,5, 10,12]});
    my $suprects = SupRects(@rects);
    print join(' ',@{$$suprects{Rect}}),"\n";
    if (!eqliste($$suprects{Rect}, [2,3, 10,12]))
    { die "Erreur dans le test de regression de SupRects";
    }
  };

# Calcule la dilatation d'un rectangle
# --------------------
sub Dilate
# --------------------
{ my ($dilate, %rect) = @_;
  if (GeometryType(\%rect) ne 'Rectangle')
  { die "Erreur: Dilate ne peut s'appliquer qu'a un rectangle";
  }
  return (Rect=>[$rect{Rect}[0]-$dilate, $rect{Rect}[1]-$dilate, $rect{Rect}[2]+$dilate, $rect{Rect}[3]+$dilate]);
}

push @Tests_non_regression, 'Dilate', sub
  { my %rect = (Rect=>[2,3, 6,9]);
    my %dilate = Dilate(10, %rect);
    print join(' ',@{$dilate{Rect}}),"\n";
    if (!eqliste($dilate{Rect}, [-8,-7, 16,19]))
    { die "Erreur dans le test de regression de Dilate";
    }
  };

# Calcule l'ecart entre une geometrie et une liste de points
# c'est a dire la distance minimum entre les points de la geometrie et les points de la liste
# --------------------
sub EcartPts
# --------------------
{ my ($geom, @pts) = @_;
  my $ecart;
  for my $n (0 .. @pts/2-1)
  { if (exists ${$geom}{P})
    { my $e = DistancePointPoints (@pts[2*$n..2*$n+1], @${$geom}{P});
      if (!defined($ecart) or ($e < $ecart))
      { $ecart = $e;
      }
    }
    if (exists ${$geom}{L})
    { foreach my $ppt (@${$geom}{L})
      { my $e = DistancePointPolyligne (@pts[2*$n..2*$n+1], @$ppt);
        if (!defined($ecart) or ($e < $ecart))
        { $ecart = $e;
        }
      }
    }
    if (exists ${$geom}{S})
    { if (PointDansMultipolygone(@pts[2*$n..2*$n+1], $geom) % 2)
      { return 0;
      }
      foreach my $polyg (@{${$geom}{S}})
      { foreach my $ppt (@$polyg)
        { my @e = DistancePointPolyligne (@pts[2*$n..2*$n+1], @$ppt);
          if (!defined($ecart) or ($e[2] < $ecart))
          { $ecart = $e[2];
          }
        }
      }
    }
  }
  return $ecart;
}

push @Tests_non_regression, 'EcartPts', sub
  { print "ecart=",EcartPts({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, (0,-10, 100,100, 200,200)),"\n";
    if (EcartPts({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, (0,-10, 100,100, 200,200)) != 10)
    { die "Erreur dans le test de regression de EcartPts";
    }
    if (EcartPts({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, (10,10, 100,100, 200,200)) != 0)
    { die "Erreur dans le test de regression de EcartPts";
    }
  };

# Calcule l'ecart entre une geometrie et une liste de points consideree comme une ligne brisee
# --------------------
sub EcartLs
# --------------------
{ my ($geom, @pts) = @_;
  my $ecart;
  for my $n (1 .. @pts/2-1)
  { my @seg = @pts[2*$n-2..2*$n+1];
    if (exists ${$geom}{P})
    { for my $p (0 .. (@${$geom}{P})/2-1)
      { my $e = DistancePointPolyligne (@{${$geom}{P}}[2*$p .. 2*$p+1], @seg);
        if (!defined($ecart) or ($e < $ecart))
        { $ecart = $e;
        }
      }
    }
    if (exists ${$geom}{L})
    { foreach my $ppt (@${$geom}{L})
      { my $e = DistanceSegPolyligne (@seg, @$ppt);
        if (!defined($ecart) or ($e < $ecart))
        { $ecart = $e;
        }
      }
    }
    if (exists ${$geom}{S})
    { if (IntersSegMPolygon(\@seg, $geom))
      { return 0;
      }
      foreach my $polyg (@{${$geom}{S}})
      { foreach my $ppt (@$polyg)
        { my $e = DistanceSegPolyligne (@seg, @$ppt);
          if (!defined($ecart) or ($e < $ecart))
          { $ecart = $e;
          }
        }
      }
    }
  }
  return $ecart;
}

push @Tests_non_regression, 'EcartLs', sub
  { if (EcartLs({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, (20,-20, 20,-100)) != 20)
    { die "Erreur dans le test de regression de EcartLs";
    }
    if (EcartLs({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, (40,40, 100,100)) != 0)
    { die "Erreur dans le test de regression de EcartLs";
    }
  };

# Calcule l'ecart entre 2 geometries, c'est a dire la distance minimum entre les points de ces geometries
# Ne fonctionne que dans certains cas, le deuxieme parametre ne peut pas etre surfacique
# Aucun des parametres ne doit etre Rectangle, Rectangle arrondi, Arc ou Ellipse
# --------------------
sub Ecart
# --------------------
{ my ($g1, $g2) = @_;
  my $ecart;
  if ((GeometryType($g2) eq 'Polygon')
   or (GeometryType($g2) eq 'MultiPolygon')
   or (GeometryType($g2) eq 'Rectangle')
   or (GeometryType($g2) eq 'RoundRectangle')
   or (GeometryType($g2) eq 'Ellipse')
   or (GeometryType($g2) eq 'Arc')
   or (GeometryType($g1) eq 'Rectangle')
   or (GeometryType($g1) eq 'RoundRectangle')
   or (GeometryType($g1) eq 'Ellipse')
   or (GeometryType($g1) eq 'Arc'))
  { die "Erreur: cas non traite dans Ecart";
  }
  if (exists ${$g2}{P})
  { my $e = EcartPts($g1, @${$g2}{P});
    if (!defined($ecart) or ($e < $ecart))
    { $ecart = $e;
    }
  }
  if (exists ${$g2}{L})
  { foreach my $ppt (@{${$g2}{L}})
    { my $e = EcartLs($g1, @$ppt);
      if (!defined($ecart) or ($e < $ecart))
      { $ecart = $e;
      }
    }
  }
  return $ecart;
}

push @Tests_non_regression, 'Ecart', sub
  { if (Ecart({S=>[[[0,0, 100,0, 0,100, 0,0]]]}, {L=>[[20,-20, 20,-100]]}) != 20)
    { die "Erreur dans le test de regression de Ecart";
    }
  };

# ==================================================
# Traitement de fichiers MIF/MID
# Les textes et les collections ne sont pas traites
# ==================================================

# Lecture d'un enregistrement du fichier MID
# Fabrique un tableau de valeurs et retourne un pointeur sur ce tableau
# correction du 19/9/07: traitement des " inclus dans le texte
# correction du 30/12/08: traitement du format e-<d> dans un decimal ou un flottant
# --------------------
sub getmid
# --------------------
{ my ($fmid, $delimiter, $entete) = @_;
  my @tab;
  my $mid = <fmid>;
#  print "delimiter='$delimiter'\n";
#  print "MID=$mid";
  foreach my $column (@{$$entete{Columns}})
  { if ($$column[1] eq 'GeometryCollection') {}
    elsif (((($$column[1] eq 'integer') or ($$column[1] eq 'smallint')) and ($mid =~ s/^(-?[0-9]+)//))
        or ((($$column[1] eq 'decimal') or ($$column[1] eq 'float')) and ($mid =~ s/^([0-9\-+\.e]+)//))
        or (($$column[1] eq 'date') and ($mid =~ s/^([0-9]*)//))
        or (($$column[1] eq 'logical') and ($mid =~ s/^(V|F)//)))
    { push @tab,$1;
    }
    elsif (($$column[1] eq 'char') and ($mid =~ s/^"([^"]*)"//)) #"
    { my $texte = $1;
      while ($mid =~ s/^"([^"]*)"//)
      { $texte .= '"'.$1;
      }
      push @tab,$texte;
    }
    else
    { die "Erreur d'analyse dans getmid: type ".$$column[1]." inconnu ou erreur de detection sur '".$mid."'";
    }
    if ((length($mid)) and ($mid !~ s/^($delimiter|\n|\r) *//))
    { die "Erreur dans getmid sur le delimiteur '".$delimiter."' ; chaine='".$mid."'";
    }
  }
  return \@tab;
}

# Les fichiers MIF/MIF sont lus et leur traitement est parametre au moyens de 2 fonctions:
# la 1ere (traite_objet) s'appelle sur chaque objet et la 2nd (traite_entete) s'appelle au debut.

# LitFichierMifMid prend en parametres:
#   verbose indique le niveau de verbosite'
#   fichier indique le nom et eventuellement le chemin des fichiers MIF/MID
#   traite_objet et traite_debut sont les 2 fonctions de traitement decrites
#     ci-dessous:

# La fonction traite_objet prend en parametres:
#   verbose indique le niveau de verbosite'
#   noobj: le numero de l'objet
#   mid est l'enregistrement du fichier .MID
#   objet est un pointeur sur une structure geometrique et graphique
#   mif est le texte correspondant au fichier .MIF

# La fonction traite_entete prend en parametres:
#   verbose indique le niveau de verbosite'
#   entete est un pointeur sur une structure d'en-tete
#   mif est le texte correspondant au fichier .MIF

# --------------------
sub LitFichierMifMid
# --------------------
{ my ($verbose, $nbmax, $fichier, $traite_objet, $traite_entete) = @_;

  if ($verbose > 9) { print ("TraiteMIFMID $Geo::ident\n"); }

  my $fmif = $fichier.'.MIF';
  open(fmif,$fmif) or die "Ouverture du fichier $fmif impossible : $!\n";
  my $fmid = $fichier.'.MID';
  open(fmid,$fmid) or die "Ouverture du fichier $fmid impossible : $!\n";

  my $etat = 0;
  my %entete=();      # l'en-tete du fichier
  my $delimiter='\t'; # le caractere delimiteur defini dans l'en-tete
  my $nbcol;          # nb de colonnes attendues
  my $nocol = 0;      # numerotation des colonnes
  my $nbobj = 0;      # nb d'objets lus
  my $prev_nbobj;
  my $typobj='';      # type d'objet au sens MapInfo
  my %geom;           # objet geometrique courant
  my @pt;             # tableau des x, y temporaire
  my $nbpt;           # nb de points attendus
  my $nbtbpt;         # nbre attendu de tableaux x, y
  my $mif='';         # texte du fichier MIF en cours de traitement
# ----
# Description des etats:
# ----------------------
# 0: demarrage, lecture des parametres d'en-tete du fichier
# 1: lecture des colones, s'execute $nbcol fois
# 2: lecture des donnees
# 3: lecture des parties de points, s'execute $nbtbpt fois
# 4: lecture des points, s'execute $npt fois
  while (<fmif>)
  { if ($etat == 0)
    { $mif .= $_;
      if (m/^Version ([0-9]*)$/i)
      { if ($verbose > 9) { print "Version: $1\n"; }
      }
      elsif (m/^Charset "([A-Za-z0-9]*)"$/i)
      { if ($verbose > 9) { print "Charset: $1\n"; }
      }
      elsif (m/^Delimiter "([,;\t])"/i)
      { $delimiter = $1;
        $entete{Delimiter} = $delimiter;
        if ($verbose > 9) { print "Delimiter: $1\n"; }
      }
      elsif (m/^Index/i)
      { if ($verbose > 9) { print "Index: $_"; }
      }
      elsif (m/^CoordSys/i)
      { $entete{CoordSys} = $_;
        if ($verbose > 9) { print "CoordSys: $_"; }
      }
      elsif (m/^Columns ([0-9]*)/i)
      { $nbcol = $1;
        $etat = 1;
        if ($verbose > 9) { print "Columns: $nbcol\n"; }
      }
      elsif (m/^Data/i)
      { if ($verbose > 9) { print "Data: $_"; }
        &$traite_entete($verbose > 9, \%entete, $mif);
        $mif = '';
        $etat = 2;
      }
      else
      { print "\"$_\" non interprete dans etat $etat\n";
        die;
      }
    }
    elsif ($etat == 1)
    { $mif .= $_;
      if (m/^ *([^ ]+) +(char|integer|decimal|smallint|float|date|logical) *\(?([0-9]*),? *([0-9]*)\)?$/i)
      { if ($verbose > 9) { print "Column: $1, $2, $3, $4\n"; }
        push @{$entete{Columns}}, [$1, lc $2, $3, $4];
        $entete{ColumnNames}{$1} = $nocol;
      }
      else
      { die "Erreur d'analyse la ligne de '$_' dans LitFichierMifMid";
      }
      $nocol++;
      $nbcol--;
      if ($nbcol == 0)
      { push @{$entete{Columns}}, ['geom','GeometryCollection'];
        $entete{ColumnNames}{'geom'} = $nocol;
        $etat = 0;
      }
    }
    elsif ($etat == 2)
    { if (m/^(Point|Line|Rect|RoundRect|Ellipse|Arc|Multipoint|Pline|Pline Multiple|Region)/i)
      { if ($typobj)
        { # StructureGeom(\%geom);
          &$traite_objet($verbose, $nbobj, getmid($fmid, $delimiter, \%entete), \%geom, $mif);
        }
        $nbobj++;
        if (($nbmax > 0) and ($nbobj > $nbmax))
        { print "Arret de LitFichierMifMid: nombre maximum d'objets ($nbmax) atteint\n";
          %geom = ();
          $typobj = '';
          last;
        }
        if (($verbose) and ($nbobj % 1000 == 0))
        { print $nbobj/1000,"k objets traites\n";
        }
        $mif = '';
        %geom = ();
        $typobj = $1;
      }
      $mif .= $_;
      if (m/^\s$/)
      { }
      elsif (m/^(Point) +([0-9.-]+) +([0-9.-]+)$/i)
      { $geom{P} = [$2, $3];
        if ($verbose > 9) { print "$typobj: $2, $3\n"; }
      }
      elsif (m/^(Line) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+)$/i)
      { $geom{L} = [[$2, $3, $4, $5]];
        if ($verbose > 9) { print "$typobj: $2, $3, $4, $5\n"; }
      }
      elsif (m/^(Rect) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+)$/i)
      { $geom{Rect} = [$2, $3, $4, $5];
        if ($verbose > 9) { print "$typobj: $2, $3, $4, $5\n"; }
      }
      elsif (m/^(RoundRect) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+)$/i)
      { $geom{RoundRect} = [$2, $3, $4, $5, $6];
        if ($verbose > 9) { print "$typobj: $2, $3, $4, $5, $6\n"; }
      }
      elsif (m/^(Ellipse) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+)$/i)
      { $geom{Ellipse} = [$2, $3, $4, $5];
        if ($verbose > 9) { print "$typobj: $2, $3, $4, $5\n"; }
      }
      elsif (m/^(Arc) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9.-]+) +([0-9-]+) +([0-9-]+)$/i)
      { $geom{Arc} =  [$2, $3, $4, $5, $6, $7];
        if ($verbose > 9) { print "$typobj: $2, $3, $4, $5, $6, $7\n"; }
      }
     elsif (m/^(Pline)$/i)
      { $nbtbpt = 1;
        $etat = 4;
        if ($verbose > 9) { print "$typobj\n"; }
      }
      elsif (m/^(Multipoint|Pline) +([0-9]+)$/i)
      { $nbtbpt = 1;
        $nbpt = $2;
        @pt = ();
        $etat = 5;
        if ($verbose > 9) { print "$typobj: $nbpt points attendus\n"; }
      }
      elsif (m/^(Pline Multiple) +([0-9]+)$/i)
      { $typobj = $1;
        $nbtbpt = $2;
        $etat = 4;
        if ($verbose > 9) { print "$typobj: $nbtbpt parties attendues\n"; }
      }
      elsif (m/^(Region) +([0-9]+)$/i)
      { $nbtbpt = $2;
        $etat = 4;
        if ($verbose > 9) { print "$typobj: $nbtbpt parties attendues\n"; }
      }
      elsif (m/^ *(Pen|Brush|Symbol) *\(([0-9.-]+),([0-9.-]+),([0-9.-]+)\) *$/i)
      { if ($verbose > 9) { print "$1 ($2,$3,$4)\n"; }
        $geom{$1} = [$2,$3,$4];
      }
      elsif (m/^ *(Symbol) *\(([0-9.-]+),([0-9.-]+),([0-9.-]+),"[^"]*",([0-9.-]+),([0-9.-]+)\) *$/i)
      { if ($verbose > 9) { print "$1 ($2,$3,$4)\n"; }
        $geom{$1} = [$2,$3,$4];
      }
      elsif (m/^ *(Brush) *\(([0-9.-]+),([0-9.-]+)\) *$/i)
      { if ($verbose > 9) { print "$1 ($2,$3,$4)\n"; }
        $geom{$1} = [$2,$3,0];
      }
      elsif (m/^ *(Center) +([0-9.-]+) +([0-9.-]+)$/i)
      { if ($verbose > 9) { print "$1 $2 $3\n"; }
        $geom{$1} = [$2,$3];
      }
      elsif (m/^ *(Smooth)$/i)
      { if ($verbose > 9) { print "$1\n"; }
        $geom{$1} = 1;
      }
      else
      { print "\"$_\" non interprete dans etat $etat\n";
        die;
      }
    }
    elsif (($etat == 4) && (m/^ *([0-9]+) *$/))
    { $mif .= $_;
      $nbpt = $1;
      @pt = ();
      $etat = 5;
      if ($verbose > 9) { print "Partie $nbtbpt: $nbpt points attendus\n"; }
    }
    elsif (($etat == 5) && (m/^([0-9-\.e]+) ([0-9-\.e]*)\s$/))
    { $mif .= $_;
      push @pt, $1, $2;
      $nbpt--;
      if ($verbose > 19) { print "Point $1 $2\n"; }
      if ($nbpt == 0)
      { if ($typobj =~ m/Multipoint/i)
        { $geom{P} = [@pt];
        }
        elsif ($typobj =~ m/(Pline|Pline Multiple)/i)
        { push @{$geom{L}}, [@pt];
        }
        elsif ($typobj =~ m/Region/i)
        { push @{$geom{R}}, [@pt];
        }
        else
        { die "ERREUR: typobj '$typobj' inconnu";
        }
        $nbtbpt--;
        if ($nbtbpt==0)
        { if ($verbose > 9) { print "Fin des parties\n"; }
          $etat = 2;
        }
        else
        { if ($verbose > 9) { print "Fin d'une partie $nbtbpt\n"; }
          $etat = 4;
        }
      }
    }
    else
    { print "\"$_\" non interprete dans etat $etat\n";
      die;
    }
# text
# collection
  }
  if ($etat == 2)
  { if ($typobj)
    { # StructureGeom(\%geom);
      &$traite_objet($verbose, $nbobj, getmid($fmid, $delimiter, \%entete), \%geom, $mif);
    }
  }
  else
  { print "Fin de lecture du MIF sur etat $etat\n";
  }
  close $fmid;
  close $fmif;
  return $nbobj;
}

push @Tests_non_regression, 'LitFichierMifMid', sub
  { print "\n",'-'x80,"\n";
    my 
    $nbobj = LitFichierMifMid(10, 0, 'essai/divers', \&AfficheGeom, sub {});
    print "$nbobj objets traites\n\n",'-'x80,"\n";
#    $nbobj = LitFichierMifMid(1, 0, 'essai/heteroclites', \&AfficheGeom, sub {});
#    print "$nbobj objets traites\n\n",'-'x80,"\n";
  };

# La fonction ci-desssous fournit un exemple d'appel a la fonction LitFichierMifMid
# ------------------------------
sub exemple_dappel_LitFichierMifMid
# ------------------------------
{
  print "Extraction de deux objets\n";

  my $fmodmif='>FMOD.MIF'; # fichier MIF modifie
  my $fmodmid='>FMOD.MID'; # fichier MID modifie

# --------------------
  my $traite_entete = sub
# --------------------
  { my ($verbose, $entete, $mif) = @_;
    print fmodmif $mif;
  };

# Les parametres d'appel sont:
#   verbose indique le degre' de verbosite'
#   noobj est le numero d'objet
#   mid est l'enregistrement du fichier .MID
#   geom est un pointeur sur un Geom
#   mif est l'enregistrement du fichier .MIF
# --------------------
  my $traite_objet = sub
# --------------------
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    if (($mid =~ m/^85/)||($mid =~ m/^25/))
    { print $mid;
      print fmodmif $mif;
      print fmodmid $mid;
      $verbose=1;
      AfficheGeom($verbose, $noobj, $mid, $geom, $mif);
    }
  };

  my $verbose = 0;
  my $nbmax = 0;                        # nb max d elements a lire
  my $fichier = 'C:\fichiersfiges\refgeo\GeoFla-Departements\DEPARTEMENT';

  open(fmodmif,$fmodmif) or die "Ouverture du fichier $fmodmif impossible : $!\n";
  open(fmodmid,$fmodmid) or die "Ouverture du fichier $fmodmid impossible : $!\n";
  my $nbobj = LitFichierMifMid ($verbose, $nbmax, $fichier, $traite_objet, $traite_entete);
  close fmodmif;
  close fmodmid;
  print "$nbobj objets traites\n";
}

# Calcule la longueur de la partie lineaire du geom
# --------------------
sub LongueurLineString
# --------------------
{ my ($ls) = @_;
  my $lon = 0;
  foreach my $ppt (@{${$ls}{L}})
  { $lon += Longueur(@$ppt);
  }
  return $lon;
}

push @Tests_non_regression, 'LongueurLineString', sub
  { if (LongueurLineString({L=>[[20,-20, 20,-100]]}) != 80)
    { die "Erreur dans le test de regression de LongueurLineString";
    }
  };

# Calcule la surface de la partie surfacique du geom
# --------------------
sub SurfacePolygon
# --------------------
{ my ($geom) = @_;
  my $surf = 0;
  if (exists ${$geom}{R})
  { foreach my $ppt (@{${$geom}{R}})
    { $surf += Surface(@{$ppt});
    }
  }
  elsif (exists ${$geom}{S})
  { foreach my $polyg (@{${$geom}{S}})
    { foreach my $ppt (@{$polyg})
      { $surf += Surface(@{$ppt});
      }
    }
  }
  return $surf;
}

push @Tests_non_regression, 'SurfacePolygon', sub
  { if (SurfacePolygon({S=>[[[0,0, 10,0, 0,10, 0,0]]]}) != 50)
    { die "Erreur dans le test de regression de SurfacePolygon";
    }
    if (SurfacePolygon({R=>[[0,0, 10,0, 0,10, 0,0]]}) != 50)
    { die "Erreur dans le test de regression de SurfacePolygon";
    }
  };

# Agrege une MultiLineString a une MultiLineString existante
# Les parametres sont les 2 geometries.
# La premiere est passee sous la forme d'un pointeur, elle est modifiee 
# et son pointeur est retourne.
# La seconde geometrie est passee sous forme de hachage
# --------------------
sub AggLineString
# --------------------
{ my ($g, %p) = @_;

# On ajoute les elements de p a la fin de g
  foreach my $ppt (@{$p{L}})
  { push @{${$g}{L}},$ppt;
  }

# Puis on essaie de racrocher 2 � 2 les ls de g
  Agg: 
  foreach my $ng0 (0 .. @{${$g}{L}}-2)
  { my $g0 = ${${$g}{L}}[$ng0];
    if (!EstFerme(@$g0))
    { my @sp0 = StartPoint(@$g0);
      my @ep0 = EndPoint(@$g0);
      foreach my $ng1 ($ng0+1 .. @{${$g}{L}} - 1)
      { my $g1 = ${${$g}{L}}[$ng1];
        if (!EstFerme(@$g1))
        { my @sp1 = StartPoint(@$g1);
          my @ep1 = EndPoint(@$g1);
# Si les 2 ls peuvent se raccrocher, alors je raccroche la seconde a la premiere et je supprime la seconde
# si j'ai effectue une modification alors je reboucle
# je suis certain de ne pas avoir de bouclage car chaque operation reduit la taille de @{${$g}{L}}
          if (eqliste(\@ep0,\@sp1))
          { push @$g0,Reste(@$g1);
            @{${$g}{L}} = (@{${$g}{L}}[0 .. $ng1-1],@{${$g}{L}}[$ng1+1 .. @{${$g}{L}} - 1]);
            redo Agg;
          }
          elsif (eqliste(\@ep0,\@ep1))
          { push @$g0,Reste(Retourne(@$g1));
            @{${$g}{L}} = (@{${$g}{L}}[0 .. $ng1-1],@{${$g}{L}}[$ng1+1 .. @{${$g}{L}} - 1]);
            redo Agg;
          }
          elsif (eqliste(\@sp0,\@ep1))
          { ${${$g}{L}}[$ng0] = [@$g1, Reste(@$g0)];
            @{${$g}{L}} = (@{${$g}{L}}[0 .. $ng1-1],@{${$g}{L}}[$ng1+1 .. @{${$g}{L}} - 1]);
            redo Agg;
          }
          elsif (eqliste(\@sp0,\@sp1))
          { ${${$g}{L}}[$ng0] = [Retourne(@$g1), Reste(@$g0)];
            @{${$g}{L}} = (@{${$g}{L}}[0 .. $ng1-1],@{${$g}{L}}[$ng1+1 .. @{${$g}{L}} - 1]);
            redo Agg;
          }
        }
      }
    }
  }
  return $g;
}

# Teste l'inclusion d'un point dans un MultiPolygon code en Geom
# Renvoit le nombre d'inclusions, un trou compte negativement
# ------------------------
sub PointDansMultipolygone
# ------------------------
{ my ($x, $y, $geom) = @_;
  my $nbinc = 0;
  foreach my $polyg (@{${$geom}{S}})
  { my $extint = 1;
    foreach my $ppt (@{$polyg})
    { $nbinc += $extint * PointDansPolygone($x, $y, @$ppt);
      $extint = -1;
    }
  }
#  print "PointDansMultipolygone($x $y,",Geom2Wkt($geom),") -> $nbinc\n";
  return $nbinc;
}

push @Tests_non_regression, 'PointDansMultipolygone', sub
  { my %pol = (S=>[[[0,0, 10,0, 0,10, 0,0]],[[10,10, 10,7, 7,10, 10,10]]]);
    if  ((!PointDansMultipolygone(2,2,\%pol))
      or (!PointDansMultipolygone(9,9,\%pol))
      or (PointDansMultipolygone(11,11,\%pol)))
    { die "Erreur dans le test de regression de PointDansMultipolygone";
    }
  };

# tri une liste de couples (nombre, valeur quelconque) par ordre croissant des nombres;
# un nombre peut correspondre a plusieurs valeurs.
# -----------------
sub trilistecouples
# -----------------
{ my $op = 1;
  while ($op)
  { $op = 0;
    for (my $i=0; $i<@_/2-1; $i++)
    { if ($_[2*$i] > $_[2*($i+1)])
      { my ($n, $p) = ($_[2*$i], $_[2*$i+1]);
        ($_[2*$i], $_[2*$i+1]) = ($_[2*($i+1)], $_[2*($i+1)+1]);
        ($_[2*($i+1)], $_[2*($i+1)+1]) = ($n, $p);
        $op = 1;
      }
    } 
  }
  return @_;
}

push @Tests_non_regression, 'trilistecouples', sub
  { my @entree = (1,'b',0,'a',4,4,3,3);
    my @sortie = trilistecouples(@entree);
    if (eqliste(\@sortie, [0,'a',1,'b',3,3,4,4]))
    { print "OK trilistecouples: ", join(',',@entree)," -> ",join(',',trilistecouples(@entree)),"\n";
    }
    else
    { print "KO trilistecouples: ", join(',',@entree)," -> ",join(',',trilistecouples(@entree)),"\n";
      die 'Test trilistecouples';
    }
  };

# Calcule l'intersection du segment avec un MultiPolygone
# Renvoit la liste des points d'intersection correspondant
# a la liste des segments composant l'intersection
# -------------------
sub IntersSegMPolygon
# -------------------
{ my ($seg, $mpol) = @_;
  my @inters=(); # liste associant a chaque u le pt correspondant
  foreach my $polyg (@{${$mpol}{S}})
  { foreach my $ppt (@{$polyg})
    { foreach my $nopt (0 .. @$ppt/2-2)
      { my @res = InterSegSeg([$$ppt[$nopt*2],
                               $$ppt[$nopt*2+1],
                               $$ppt[$nopt*2+2],
                               $$ppt[$nopt*2+3]],
                              $seg);
        if (@res)
        { push @inters, $res[3], [$res[0], $res[1]];
        }
      }
    }
  }
#  foreach my $p (@inters) { print "  $p\n"; }
  @inters = trilistecouples @inters;
  my @res = ();
  for my $i (0 .. @inters/2-1)
  { push @res, ${$inters[2*$i+1]}[0], ${$inters[2*$i+1]}[1];
  }
  return @res;
}

my $epsilon = 1;
# sous-partie de IntersMLineStringMPolygon permettant de construire une liste de segments
# correspondant a l'intersection d'un segment avec un polygone
# Le segment est pass� comme une liste de 2 points
sub constructionListeSegments
{ my ($mpol, @seg) = @_;
#  print 'constructionListeSegments(mpol=',Geom2Wkt($mpol),', seg=',join(' ',@seg),")\n";
  my @lseg = ();
  if (PointDansMultipolygone(@seg[0..1], $mpol) % 2)
  { push @lseg, @seg[0..1];
  }
  push @lseg, IntersSegMPolygon(\@seg, $mpol);
  if (PointDansMultipolygone(@seg[2..3], $mpol) % 2)
  { push @lseg, @seg[2..3];
  }
#  print 'Lseg: ',($#{@lseg}+1)/4,' segments: ',join(' ',@lseg),"\n";
  if ((@lseg % 4) != 0)
  {#  print "constructionListeSegments incorrecte: nombre impair de points\n";
    if (Norme($seg[2] - $seg[0], $seg[3] - $seg[1]) < $epsilon)
    { return ();
    }
    else
    { my @lseg1 = constructionListeSegments($mpol, ( @seg[0..1], ($seg[2]+$seg[0])/2, ($seg[3]+$seg[1])/2 ) );
      my @lseg2 = constructionListeSegments($mpol, ( ($seg[2]+$seg[0])/2, ($seg[3]+$seg[1])/2, @seg[2..3] ) );
      if (@lseg1 == 0)
      { return @lseg2;
      }
      elsif (@lseg2 == 0)
      { return @lseg1;
      }
      elsif (eqliste([@lseg1[-2..-1]], [@lseg2[0..1]]))
      { pop @lseg1;
        pop @lseg1;
        push @lseg1, @lseg2[2..@lseg2-1];
        return @lseg1;
      } # correction d'un bug le 22/6/05, oubli du cas else
      else
      { push @lseg1, @lseg2;
        return @lseg1;
      }
    }
  }
  else
  { # print "constructionListeSegments OK\n";
    return @lseg;
  }
}

# Calcule l'intersection entre un MultiLineString et un MultiPolygon
# Renvoit un MLineString
# L'algorithme est le suivant:
# on balaye les segments du MLineString et pour chaque segment
# Appel de IntersSegMPolygon qui construit une liste de points
# Si le point initial du segment est dans le polygone alors on l'ajoute avant la liste
# Si le point final du segment est dans le polygone alors on l'ajoute apres la liste
# Si la liste contient un nombre pair de points alors il s'agit de la liste de segments que l'on agrege au resultat
# Sinon il y a un point double qui est complexe a traiter
#   si la longueur du segment est inferieure a 1 m (epsilon) je l'abandonne
#   sinon je rappelle recursivement la fonction sur les deux moiti�s du segment
# ------------------------------
sub IntersMLineStringMPolygon
# ------------------------------
{ my ($mls, $mpol) = @_;
  my %resultat = (); # la MLinestring resultat
#  print "--> IntersMLineStringMPolygon\n";
  foreach my $ls (@{${$mls}{L}})
  { my @lseg = (); # la liste des segments resultat de l'intersection en construction
    for my $nseg (1 .. @$ls/2-1)
    {# Balayage des segments de la linestring
#      print "  nseg=$nseg\n";
      my @cseg = constructionListeSegments($mpol, @$ls[2*$nseg-2..2*$nseg+1]);
#      print "Retour de constructionListeSegments -> ",join(' ',@cseg),"\n";
      push @lseg, @cseg;
    }
#    print 'lseg=',join(' ',@lseg),"\n";
    foreach my $nseg (0 .. @lseg/4-1)
    {#  print "****construction du segment ",join(' ',@lseg[4*$nseg .. 4*$nseg+3]),"\n";
      if (Norme($lseg[4*$nseg+2] - $lseg[4*$nseg], $lseg[4*$nseg+3] - $lseg[4*$nseg+1]) > 0)
      { AggLineString(\%resultat, (L=>[[@lseg[4*$nseg .. 4*$nseg+3]]]));
      }
    }
  }
#  print "<-- IntersMLineStringMPolygon\n";
  return %resultat;
}

push @Tests_non_regression, 'IntersMLineStringMPolygon', sub
  { print "\n",'-'x80,"\n";
    my %mls  = (L=>[[0,0, 15,10, 20,0]]);
    my %mpol = (S=>[[[10,20, 10,10, 20,10, 10,20]]]);
    my %inters = IntersMLineStringMPolygon(\%mls, \%mpol);
    if (GeometryType(\%inters,"") ne 'Empty')
    { die "Test de regression de IntersMLineStringMPolygon sur point du segment faux";
    }
    
    my %mls  = (L=>[[-20,0,  0,20,  20,0]]);
    my %mpol = (S=>[[[10,20, 10,10, 20,10, 10,20]]]);
    my %inters = IntersMLineStringMPolygon(\%mls, \%mpol);
    if (GeometryType(\%inters,"") ne 'Empty')
    { die "Test de regression de IntersMLineStringMPolygon point du polygone ligne longue faux";
    }
    
    my %mls  = (L=>[[0,20, 20,0]]);
    my %mpol = (S=>[[[10,20, 10,10, 20,10, 10,20]]]);
    my %inters = IntersMLineStringMPolygon(\%mls, \%mpol);
    if (GeometryType(\%inters,"") ne 'Empty')
    { die "Test de regression de IntersMLineStringMPolygon point du polygone ligne courte faux";
    }
    
    my %mls  = (L=>[[0,1, 1,1, 1,0]]);
    my %mpol = (S=>[[[10,20, 10,10, 20,10, 10,20]]]);
    my %inters = IntersMLineStringMPolygon(\%mls, \%mpol);
    if (GeometryType(\%inters,"") ne 'Empty')
    { die "Test de regression de IntersMLineStringMPolygon point double faux";
    }

# --------------------
# Test de non regression lisant le fichier testsnonregression\intmlsmp.MIF/MID
# --------------------
    my @tmls;
    my @tmpol;
    my $fmodmif='>testsnonregression\intmlsmpout.MIF'; # fichier MIF en sortie
    my $fmodmid='>testsnonregression\intmlsmpout.MID'; # fichier MID en sortie
    open(fmodmif,$fmodmif) or die "Ouverture du fichier $fmodmif impossible : $!\n";
    open(fmodmid,$fmodmid) or die "Ouverture du fichier $fmodmid impossible : $!\n";
    my $traite_entete = sub
    { my ($verbose, $entete, $mif) = @_;
      print fmodmif $mif;
    };
    my $traite_objet = sub
    { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
      print GeometryType($geom),': ',join(' ', @$mid),Geom2Wkt($geom),"\n";
      if ((GeometryType($geom) eq 'LineString') or (GeometryType($geom) eq 'MultiLineString'))
      { push @tmls, [$mid, {L=>$$geom{L}}];
      }
      elsif ((GeometryType($geom) eq 'Polygon') or (GeometryType($geom) eq 'MultiPolygon'))
      { push @tmpol, [$mid, {S=>$$geom{S}}];
      }
    };
    LitFichierMifMid (0, 0, 'testsnonregression\intmlsmp', $traite_objet, $traite_entete);
    foreach my $mpol (@tmpol)
    { foreach my $mls (@tmls)
      { print join(' ',@{$$mpol[0]}),' X ',join(' ',@{$$mls[0]}),"\n";
        print Geom2Wkt($$mls[1]),"\n";
        print Geom2Wkt($$mpol[1]),"\n";
        my %inters = IntersMLineStringMPolygon($$mls[1], $$mpol[1]);
        if (GeometryType(\%inters) eq 'Empty')
        { print "Intersection vide\n";
        }
        else
        { print "Resultat de l'intersection: ",Geom2Wkt(\%inters),"\n";
          print fmodmif Geom2Mif(\%inters);
        }
      }
    }
    close fmodmif;
    close fmodmid;

    print "\n\n",'-'x80,"\n";
  };

# Fabrique le WKT d'un Geom
# Les primitives Arc, Ellipse, Rect, RoundRect et GeometryCollection ne sont pas traitees 
# et provoquent une erreur
# --------------------
sub Geom2Wkt
# --------------------
{ my ($geom) = @_;
  my $gt = GeometryType($geom);
  if ($gt eq '') { return '';}
  my $wkt = $GeometryType{$gt}[1];
  if (($gt eq 'Point') or ($gt eq 'MultiPoint'))
  { return $wkt . '(' . chpts(1,@{${$geom}{P}}) . ')';
  }
  elsif (($gt eq 'Line') or ($gt eq 'LineString') or ($gt eq 'LinearRing'))
  { my $ppt = ${${$geom}{L}}[0];
    return $wkt . '(' . chpts(1,@{$ppt}) . ')';
  }
  elsif ($gt eq 'MultiLineString')
  { $wkt .= '(';
    foreach my $ppt (@{${$geom}{L}})
    { $wkt .=  '(' . chpts(1,@{$ppt}). '),';
    }
    $wkt =~ s/,$/)/;
    return $wkt;
  }
  elsif ($gt eq 'Polygon')
  { if (${$geom}{R}) { StructureGeom ($geom); }
    my $polyg = ${${$geom}{S}}[0];
    $wkt .= '(';
    foreach my $ppt (@{$polyg})
    { $wkt .= '(' . chpts(1,@{$ppt}). '),';
    }
    $wkt =~ s/,$/)/;
    return $wkt;
  }
  elsif ($gt eq 'MultiPolygon')
  { if (${$geom}{R}) { StructureGeom ($geom); }
    $wkt .= '(';
    foreach my $polyg (@{${$geom}{S}})
    { $wkt .= '(';
      foreach my $ppt (@{$polyg})
      { $wkt .= '(' . chpts(1,@{$ppt}). '),';
      }
      $wkt =~ s/,$/),/;
    }
    $wkt =~ s/,$/)/;
    return $wkt;
  }
  elsif ($gt eq 'Rectangle')
  { $wkt .= '(('.${$geom}{Rect}[0].' '.${$geom}{Rect}[1]
            .','.${$geom}{Rect}[2].' '.${$geom}{Rect}[1]
            .','.${$geom}{Rect}[2].' '.${$geom}{Rect}[3]
            .','.${$geom}{Rect}[0].' '.${$geom}{Rect}[3]
            .','.${$geom}{Rect}[0].' '.${$geom}{Rect}[1]
            .'))';
    return $wkt;
  }
  else
  { die "ERREUR: $gt non traite dans Geom2Wkt";
  }
}

# Fabrique un Geom a partir d'un WKT
# La primitive GeometryCollection n'est pas traitee et provoque une erreur
# Le parametre est le WKT ; le resultat est un Geom.
# --------------------
sub Wkt2Geom
# --------------------
{ my ($wkt) = @_;
  my %geom; # le resultat en construction
  $wkt =~ s/\(/</g;
  $wkt =~ s/\)/>/g;
#  print "-->$wkt\n";
  if ($wkt =~ m/^(POLYGON|MULTIPOLYGON)</)
  { MultiPolygon: while (1)
    { my @rings=();
      Polygon: while (1)
      { my @pt = ();
        while ($wkt =~ s/^(POLYGON<<|MULTIPOLYGON<<<)([0-9-.]+) ([0-9-.]+),?/\1/)
        { push @pt,$2,$3;
        }
        push @rings, [@pt];
        @pt = ();
        next Polygon if ($wkt =~ s/^(MULTIPOLYGON<<)<>,/\1/);
        next Polygon if ($wkt =~ s/^(POLYGON<)<>,/\1/);
        push @{$geom{S}}, [@rings];
        last MultiPolygon if ($wkt =~ s/^MULTIPOLYGON<<<>>>//);
        last MultiPolygon if ($wkt =~ s/^POLYGON<<>>//);
        next MultiPolygon if ($wkt =~ s/^(MULTIPOLYGON<)<<>>,/\1/);
        print "WKT=$wkt\n\n";
        die "Erreur dans le decodage des MULTIPOLYGON";
      }
    }
  }
  elsif ($wkt =~ m/^(LINE|LINESTRING|MULTILINESTRING)</)
  { MultiLineString: while (1)
    { my @pt;
      while ($wkt =~ s/^(LINE<|LINESTRING<|MULTILINESTRING<<)([0-9-.]+) ([0-9-.]+),?/\1/)
      { push @pt, $2, $3;
      }
      push @{$geom{L}}, [@pt];
      last MultiLineString if ($wkt =~ s/^(LINE<>|LINESTRING<>|MULTILINESTRING<<>>)//);
      @pt = ();
      next MultiLineString if ($wkt =~ s/^(MULTILINESTRING<)<>,/\1/);
      print "WKT=$wkt\n\n";
      die "Erreur dans le decodage des MULTILINESTRING";
    }
  }
  elsif ($wkt =~ m/^(POINT|MULTIPOINT)</)
  { while ($wkt =~ s/^(POINT<|MULTIPOINT<)([0-9-.]+) ([0-9-.]+),?/\1/)
    { push @{$geom{P}}, $2, $3;
    }
  }
  else
  { die "WKT $wkt inconnu dans Wkt2Geom";
  }
  return %geom;
}

# Fabrique une chaine MIF a partir d'un Geom
# --------------------
sub Geom2Mif
# --------------------
{ my ($geom) = @_;
  my $gt = GeometryType($geom);
  my $mif = '';

  if ($gt eq 'Point')
  { $mif .= 'Point '.${${$geom}{P}}[0].' '.${${$geom}{P}}[1]."\n";
    if (${$geom}{Symbol})
    { $mif .= '  Symbol ('.${${$geom}{Symbol}}[0].','.${${$geom}{Symbol}}[1].','.${${$geom}{Symbol}}[2].")\n";
    }
    return $mif;
  }
  elsif ($gt eq 'Line')
  { $mif .= 'Line '.${${$geom}{L}}[0][0].' '.${${$geom}{L}}[0][1].' '
                   .${${$geom}{L}}[0][2].' '.${${$geom}{L}}[0][3]."\n";
    if (${$geom}{Pen})
    { $mif .= '  Pen ('.${${$geom}{Pen}}[0].','.${${$geom}{Pen}}[1].','.${${$geom}{Pen}}[2].")\n";
    }
    return $mif;
  }
  if ($gt eq 'MultiPoint')
  { $mif .= 'MultiPoint '.(($#{@{${$geom}{P}}}+1)/2)."\n";
    foreach my $i (0 .. ($#{@{${$geom}{P}}}-1)/2)
    { $mif .= ${${$geom}{P}}[2*$i] . ' ' . ${${$geom}{P}}[2*$i+1] . "\n";
    }
    if (${$geom}{Symbol})
    { $mif .= '  Symbol ('.${${$geom}{Symbol}}[0].','.${${$geom}{Symbol}}[1].','.${${$geom}{Symbol}}[2].")\n";
    }
    return $mif;
  }
  elsif (($gt eq 'LineString') or ($gt eq 'LinearRing'))
  { my $ppt = ${${$geom}{L}}[0];
    $mif .= 'Pline '.(($#{@{$ppt}}+1)/2)."\n";
    foreach my $i (0 .. ($#{@{$ppt}}-1)/2)
    { $mif .= ${$ppt}[2*$i] . ' ' . ${$ppt}[2*$i+1] . "\n";
    }
    if (${$geom}{Pen})
    { $mif .= '  Pen ('.${${$geom}{Pen}}[0].','.${${$geom}{Pen}}[1].','.${${$geom}{Pen}}[2].")\n";
    }
    return $mif;
  }
  elsif ($gt eq 'MultiLineString')
  { $mif .= 'Pline Multiple '.(@{${$geom}{L}}+0)."\n";
    foreach my $ppt (@{${$geom}{L}})
    { $mif .= ' '.(@{$ppt}/2)."\n";
      foreach my $i (0 .. @{$ppt}/2-1)
      { $mif .= ${$ppt}[2*$i] . ' ' . ${$ppt}[2*$i+1] . "\n";
      }
    }
    if (${$geom}{Pen})
    { $mif .= '  Pen ('.${${$geom}{Pen}}[0].','.${${$geom}{Pen}}[1].','.${${$geom}{Pen}}[2].")\n";
    }
    return $mif;
  }
  elsif (($gt eq 'MultiPolygon') or ($gt eq 'Polygon'))
  { if (exists ${$geom}{S})
    { my $nbsections = 0;
      foreach my $polyg (@{${$geom}{S}})
      { $nbsections += @{$polyg};
      }
      $mif .= "Region $nbsections\n";
      foreach my $polyg (@{${$geom}{S}})
      { foreach my $ppt (@{$polyg})
        { $mif .= ' '.(@{$ppt}/2)."\n";
          foreach my $i (0 .. @{$ppt}/2-1)
          { $mif .= ${$ppt}[2*$i] . ' ' . ${$ppt}[2*$i+1] . "\n";
          }
        }
      }
    }
    elsif (exists ${$geom}{R})
    {$mif .= 'Region '.(@{${$geom}{R}}+0)."\n";
      foreach my $ppt (@{${$geom}{R}})
      { $mif .= ' '.(($#{@{$ppt}}+1)/2)."\n";
        foreach my $i (0 .. @{$ppt}/2-1)
        { $mif .= ${$ppt}[2*$i] . ' ' . ${$ppt}[2*$i+1] . "\n";
        }
      }
    }
    if (exists ${$geom}{Pen})
    { $mif .= '  Pen ('.${${$geom}{Pen}}[0].','.${${$geom}{Pen}}[1].','.${${$geom}{Pen}}[2].")\n";
    }
    if (exists ${$geom}{Brush})
    { $mif .= '  Brush ('.${${$geom}{Brush}}[0].','.${${$geom}{Brush}}[1].','.${${$geom}{Brush}}[2].")\n";
    }
    if (exists ${$geom}{Center})
    { $mif .= '  Center '.${${$geom}{Center}}[0].' '.${${$geom}{Center}}[1]."\n";
    }
    return $mif;
  }
  else
  { die "ERREUR: $gt non traite dans Geom2Mif";
  }
}

# Definit le champ CoordSys de l'entete pour les systemes connus
# --------------------
my %CoordSys =
# --------------------
( 'Lambert II carto Paris' =>
    'CoordSys Earth Projection 3, 1002, "m",'
#   .' 0, 46.8, 45.89891889, 47.69601444, 600000, 2200000 Bounds (-113967455.167, -106367759.392) (115167455.167, 122767150.942)'."\n",
   .' 0, 46.8, 45.9, 47.7, 600000, 2200000 Bounds (-113967455.167, -106367759.392) (115167455.167, 122767150.942)'."\n",
  'Lambert93' =>
    'CoordSys Earth Projection 3, 999, 0, 0.0000, 0.0000, 0.0000, "m",'
   .' 3.000000000000, 46.500000000000, 44.000000000000, 49.000000000000, 700000.000, 6600000.000'."\n",
  'UTM20N' =>
    'CoordSys Earth Projection 8, 104, "m",'
   .' -63, 0, 0.9996, 500000, 0 Bounds (-7745844.29597, -9997964.94324) (8745844.29597, 9997964.94324)'."\n",
  'UTM22N' =>
    'CoordSys Earth Projection 8, 104, "m",'
   .' -51, 0, 0.9996, 500000, 0 Bounds (-7745844.29597, -9997964.94324) (8745844.29597, 9997964.94324)'."\n",
  'UTM40S' =>
    'CoordSys Earth Projection 8, 104, "m",'
   .'  57, 0, 0.9996, 500000, 10000000 Bounds (-7745844.29597, 2035.05676326) (8745844.29597, 19997964.9432)'."\n",
);
# La fonction CoordSys permet d'acceder a ces donnees
sub CoordSys { return $CoordSys{$_[0]}; }

# Fabrique une chaine MIF a partir d'une entete
# --------------------
sub Entete2Mif
# --------------------
{ my ($entete) = @_;
  my $mif = "Version 650\n"
           .'Charset "WindowsLatin1"'."\n"
           .'Delimiter "'.$$entete{Delimiter}.'"'."\n"
           .$$entete{CoordSys}
           .'Columns '.(@{$$entete{Columns}} - 1)."\n";
  foreach my $column (@{$$entete{Columns}})
  { if ($$column[1] ne 'GeometryCollection')
    { $mif .= '  '.$$column[0].' '.$$column[1];
      if ($$column[2] eq '')
      { }
      elsif ($$column[3] eq '')
      { $mif .= '('.$$column[2].')';
      }
      else
      { $mif .= '('.$$column[2].','.$$column[3].')';
      }
      $mif .= "\n";
    }
  }
  $mif .= "Data\n";
  return $mif;
}

# Test de non regression du package
# --------------------
sub Tests_non_regression
# --------------------
{ my @liste = reverse @Tests_non_regression;
  while (my $nom_du_test = pop @liste)
  { print "Execution du test de $nom_du_test\n";
    my $fonc = pop @liste;
    &$fonc;
  }
  print "Resultat positif des tests de non regression\n";
}
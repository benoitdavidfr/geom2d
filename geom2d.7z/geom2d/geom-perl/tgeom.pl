#!/usr/bin/perl
# tgeom - Benoit DAVID - 15/3/2008 12:00
# Test et utilisation du package Geom.pm

use Geom;
use strict;

if (1)
{ print "Test de non regression\n";
  Tests_non_regression;
}
# =========================== Test de StructureGeom ======================
elsif (0)
{ my $geom = {R=>[[0,0, 100,0, 100,100, 0,100, 0,0],   # contour exterieur
                  [10,10, 90,10, 90,90, 10,90, 10,10], # 1er trou
                  [20,20, 80,20, 80,80, 20,80, 20,20], # exterieur inclus dans 0
                  [30,30, 70,30, 70,70, 30,70, 30,30], # trou du precedent
                  [91,91, 99,91, 99,99, 91,99, 91,91], # autre trou du contour exterieur
                  [92,92, 98,92, 98,98, 92,98, 92,92], # exterieur dans le precedent
                 ]};
  AfficheGeom(100,0,[''],$geom,'');
#  print "VerifieIntegrite=",VerifieIntegrite($geom),"\n";
  StructureGeom($geom);
  AfficheGeom(100,0,[''],$geom,'');
}
# ========= Affichage du rectangle englobant de chaque objet du fichier MIF/MID ======
elsif (1)
{ my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    StructureGeom($geom);
    my %br = Boundrect(%$geom);
    print $noobj,';',$br{Rect}[0],';',$br{Rect}[1],';',$br{Rect}[2],';',$br{Rect}[3],"\n";
  };

  LitFichierMifMid (
    0, 0,
#    'D:\\geodata\\ep-mif\\pnzc2004',
    'D:\\geodata\\ep-mif\\sic0706',
#    'FR4201797',
#    'FR4201797desagrege',
    $traite_objet, sub {});
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Lecture des zones d'occupation du sol\n";
  my %brush;

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    $mif =~ m/(Brush \([0-9]*,[0-9]*,[0-9]*\))/;
#    print $$mid[0],',',$1,"\n";
    $brush{$$mid[0]}=$1;
  };

  LitFichierMifMid (
    0, 0,
    'C:\fichiersfiges\refgeo\Route500-03\HABILLAGE\OCS',
    $traite_objet, sub {});
  foreach my $k (keys %brush)
  { print "$k -> ",$brush{$k},"\n";
  }
#  LitFichierMifMid (0, 643, 'C:\fichiersfiges\refgeo\Route500-03\zmifmid\ROUTE500_mif_FR\RT500_ED8_FP_M3\HABILLAGE\ZONE_OCCUPATION_SOL', $traite_objet, $traite_entete);
}
# =========================== Autre traitement possible ======================
elsif (1)
{ print "Modification du brush des zones d'occupation du sol\n";

  my $fmodmif='>FMOD.MIF'; # fichier MIF modifie
  my $fmodmid='>FMOD.MID'; # fichier MID modifie

# --------------------
  my $traite_entete = sub
# --------------------
  { my ($verbose, $entete, $mif) = @_;
    open(fmodmif,$fmodmif) or die "Ouverture du fichier $fmodmif impossible : $!\n";
    open(fmodmid,$fmodmid) or die "Ouverture du fichier $fmodmid impossible : $!\n";
    print fmodmif $mif;
  };

# --------------------
  my $traite_objet = sub
# --------------------
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    my %brush =
    ( 'For�t' => 'Brush (2,6356912,16777215)',
      'B�ti'  => 'Brush (2,16769722,16777215)',
      'Eau'   => 'Brush (2,10543359,16777215)',
    );
    my $b;
    if (exists $brush{$$mid[0]})
    { $b = $brush{$$mid[0]};
      $mif =~ s/Brush *\([0-9]+,[0-9]+,[0-9]+\)/$b/;
    }
    else
    { die "nature ",$$mid[0]," inconnue\n";
    }
    print fmodmif $mif;
    print fmodmid '"',$$mid[0],'"',"\n";
  };

  LitFichierMifMid (0, 0, 'C:\fichiersfiges\refgeo\Route500-03\zmifmid\ROUTE500_mif_FR\RT500_ED8_FP_M3\HABILLAGE\ZONE_OCCUPATION_SOL', $traite_objet, $traite_entete);
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    print "MID=",join('|',@$mid),"\n";
    AfficheGeom(10, $noobj, $mid, $geom, "\n");
  };
  LitFichierMifMid (0, 10,
    'C:\fichiersfiges\refgeo\Route500-03\zmifmid\ROUTE500_mif_FR\RT500_ED8_FP_M3\HABILLAGE\ZONE_OCCUPATION_SOL',
    $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test\n";
  my %geom = ();
  print 'WKT=',Geom2Wkt(\%geom),"\n"
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test de PointDansMultipolygone\n";
  my %pol = (S=>[[[0,0, 10,0, 0,10, 0,0]],[[10,10, 10,7, 7,10, 10,10]]]);
  AfficheGeom(10,1,['polygone'],\%pol,"");
  foreach my $pt ([2,2],[9,9],[11,11])
  { print "PointDansMultipolygone(@$pt,\%pol) -> ",PointDansMultipolygone(@$pt,\%pol),"\n";
  }
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test de IntersSegMPolygon\n";
  my %mpol = (S=>[[[0,0, 10,0, 0,10, 0,0]],[[10,10, 10,7, 7,10, 10,10]]]);
  AfficheGeom(10,1,['mpolygone'],\%mpol,"");
  my $seg = [5,-5, 5,10];
  print 'Intersection avec ',chpts(1,@$seg),' -> ',chpts(1,IntersSegMPolygon($seg,\%mpol)),"\n";
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test de IntersMLineStringMPolygon\n";
  my %pol = (S=>[[[0,0, 10,0, 0,10, 0,0]],[[10,10, 10,7, 7,10, 10,10]]]);
  AfficheGeom(10,1,['polygone'],\%pol,"");
  my %ls = (L=>[[5,-5, 5,12, 12,7]]);
  AfficheGeom(10,2,['ligne'],\%ls,"");
  my %inters = IntersMLineStringMPolygon(\%ls,\%pol);
  AfficheGeom(10,3,['intersection'],\%inters,"");
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Test de la fonction FusionneGeom\n";
  my %p = (L => [[1,1, 2,2],[4,4, 10,10]]);
  AfficheGeom(11, 1, [], \%p, "");
  my %g = (L => [[1,1, 0,0],[4,4, 3,3, 2,2],[9,9, 10,10]]);
  AfficheGeom(11, 2, [], \%g, "");
  FusionneGeom(\%g, %p);
  AfficheGeom(11, 3, [], \%g, "");
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Test de la fonction Geom2Mif\n";

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    my $wkt = Geom2Wkt($geom);
    my %g = Wkt2Geom ($wkt);
    my $mif2 = Geom2Mif(\%g);
    print $mid;
    print $mif2;
  };

  LitFichierMifMid (0, 0, 'essai\essai', $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Affichage des objets\n";

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    print "MID=",join('|',@$mid),"\n";
    AfficheGeom(0, $noobj, "\n", $geom, "\n");
  };

  LitFichierMifMid (0, 0, 'essai\essai', $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Test de la fonction Wkt2Geom\n";

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    my $wkt = Geom2Wkt($geom);
    print $mid."WKT=$wkt\n";
    my %g = Wkt2Geom ($wkt);
    AfficheGeom(10, $noobj, "\n", \%g, "\n");
  };

  LitFichierMifMid (10, 3, 'essai\essai', $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Test de la fonction Geom2Wkt\n";

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    print join(' ',@$mid),"-->WKT=",Geom2Wkt($geom),"\n";
  };

  LitFichierMifMid (0, 0, 'essai\essai', $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Exemple d'appel de LitFichierMifMid\n";
  exemple_dappel_LitFichierMifMid;
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test de l'affichage d'un objet S\n";
  
  my %geom = 
  ( 'geometryType' => 'Test',
    'S' =>[[[0,0, 1,1, 2,2],[5,5, 6,6]],[[10,10, 11,11, 12,12, 13,13]]]
  );
  AfficheGeom(10, 5, "\n", \%geom, "\n");
  if (!VerifieIntegrite(\%geom))
  { print "Objet non integre\n";
  }
}
# =========================== Autre traitement possible ======================
elsif (1)
{ print "Test d'InterSegSeg\n";
  print join(' ',InterSegSeg([0,0, 1,0], [0,0, 0,1])),"\n";
  print join(' ',InterSegSeg([-1,0, 1,0], [0,-1, 0,1])),"\n";
  print join(' ',InterSegSeg([0,0, 1,1], [0,1, 1,0])),"\n";
  print join(' ',InterSegSeg([0,0, 1,1], [1,0, 2,1])),"\n";
  print join(' ',InterSegSeg([0,0, 1,1], [2,2, 3,3])),"\n";
}
# =========================== Autre traitement possible ======================
elsif (0)
{ print "Test des fonctions geometriques\n";
  print Longueur(0,0),"\n";
  print Longueur(0,0, 1,1),"\n";
  print Longueur(0,0, 1,1, 0,10, 10,0),"\n";
  my @pt = (1,1);
  my @pol = (0,0, 0,10, 10,0, 0,0);
  print "Surface(",join(',',@pol),") ->",Surface(@pol),"\n";
  print "PointDansPolygone(",join(',',@pt),",",join(',',@pol),") -> ",PointDansPolygone(@pt,@pol),"\n";
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Test d'integrite\n";

  my $traite_objet = sub
  { my ($verbose, $noobj, $mid, $geom, $mif) = @_;
    if (!VerifieIntegrite($geom))
    { AfficheGeom(10, $noobj, $mid, $geom, $mif);
    }
    if (!VerifieIntegrite($geom))
    { print "Apres StructureGeom:\n";
      AfficheGeom(10, $noobj, $mid, $geom, $mif);
    }
  };

  LitFichierMifMid (0, 0, 'essai\essai', $traite_objet, sub { });
}
# =========================== Autre traitement possible ======================
elsif (0)
{
  print "Affichage les geom du fichier essai en utilisant le package $Geom::ident\n";
  LitFichierMifMid (0, 0, 'essai\essai', \&AfficheGeom, sub { });
}
# =========================== Autre traitement possible ======================
# -------------------- Fin de la partie a adapter ------------------
else
{ die "Rien a executer";
}